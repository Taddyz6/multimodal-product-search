"""Publication-style vector figures from existing result records; no new experiment."""
from pathlib import Path
import json,math,hashlib,re
R=Path(__file__).resolve().parent.parent
W=R.parents[2]
E=R/'evidence';F=R/'figures'
SOURCES={};VALUES=[]
def load(rel):
 p=W/rel;SOURCES[rel]=hashlib.sha256(p.read_bytes()).hexdigest();return json.loads(p.read_text())
def val(rel,ptr):
 j=load(rel)
 for p in ptr.split('/')[1:]:
  p=p.replace('~1','/').replace('~0','~');j=j[int(p)] if isinstance(j,list) else j[p]
 VALUES.append(dict(source_path=rel,json_pointer=ptr,value=j));return j
FONT=r'font=\sffamily\fontsize{8}{9.4}\selectfont'
P=lambda x,y:f'({x:.3f},{y:.3f})'
class Fig:
 def __init__(self,h):self.h=h;self.a=[r'\begin{tikzpicture}[x=1pt,y=1pt,'+FONT+r',>=Latex]',r'\path[use as bounding box] (0,0) rectangle (500,'+str(h)+');']
 def add(self,t):self.a.append(t)
 def line(self,x1,y1,x2,y2,opt='draw=black!65,line width=.5pt'):self.add(r'\draw['+opt+'] '+P(x1,y1)+'--'+P(x2,y2)+';')
 def text(self,x,y,s,opt=''):self.add(r'\node['+opt+'] at '+P(x,y)+' {'+s+'};')
 def box(self,x,y,w,h,s,color='reportblue',fill=5,name=''):
  self.add(r'\node[draw='+color+',fill='+color+f'!{fill},line width=.65pt,rounded corners=1.5pt,align=center,text width={w-8}pt,minimum width={w}pt,minimum height={h}pt,inner sep=3pt'+'] '+('('+name+') ' if name else '')+'at '+P(x,y)+' {'+s+'};')
 def arrow(self,a,b,opt=''):self.add(r'\draw[-{Latex[length=3.4pt]},line width=.65pt,draw=black!65'+(','+opt if opt else '')+'] '+a+'--'+b+';')
 def end(self,name):
  self.add(r'\end{tikzpicture}')
  text='\n'.join(self.a)+'\n'
  def scaled(m):
   size=max(10.2,float(m[1])*1.275);lead=max(size*1.15,float(m[2])*1.275)
   return r'\fontsize{'+f'{size:.3f}'+r'}{'+f'{lead:.3f}'+r'}'
  text=re.sub(r'\\fontsize\{([0-9.]+)\}\{([0-9.]+)\}',scaled,text)
  if name=='protocol.tex':
   text='\n'.join(re.sub(r'\\fontsize\{[0-9.]+\}\{[0-9.]+\}',lambda _:r'\fontsize{9}{10.4}',line) if '(437.100,165.000)' in line or '(477.700,165.000)' in line else line for line in text.splitlines())+'\n'
  (F/name).write_text(text)
# 1. Architecture: readable modules, separate cached catalog assets and runtime inputs.
f=Fig(285)
f.text(0,275,r'\textbf{a}\quad Frozen catalog assets', r'anchor=west,font=\sffamily\bfseries\fontsize{9}{10}\selectfont')
f.box(48,218,90,59,r'Product catalog\\164,900 products\\text + image mask',color='reportgrey',fill=3,name='catalog')
f.box(165,242,110,36,r'SBERT product vectors\\384 dimensions',name='sprod')
f.box(165,189,110,42,r'SQID CLIP vectors\\title + image, 768-D',color='reportteal',name='cprod')
f.box(302,218,116,60,r'Train-only calibration\\+ image-aware fallback\\'+r'$\alpha=\beta=0.5$',name='cal')
f.box(441,218,112,60,r'Fusion FlatIP index\\1,153 dimensions\\fixed product order',name='index')
f.add(r'\draw[-{Latex[length=3.4pt]},line width=.65pt,draw=black!65] (catalog.east)--(102,218)|-(sprod.west);')
f.add(r'\draw[-{Latex[length=3.4pt]},line width=.65pt,draw=black!65] (102,218)|-(cprod.west);')
f.add(r'\draw[-{Latex[length=3.4pt]},line width=.65pt,draw=black!65] (sprod.east)--(232,242)|-(cal.west);')
f.add(r'\draw[-{Latex[length=3.4pt]},line width=.65pt,draw=black!65] (cprod.east)--(232,189)|-(cal.west);')
f.arrow('(cal.east)','(index.west)')
f.line(0,159,500,159,'draw=black!20,line width=.5pt')
f.text(0,145,r'\textbf{b}\quad Query-time retrieval and ranking',r'anchor=west,font=\sffamily\bfseries\fontsize{9}{10}\selectfont')
f.box(38,92,73,44,r'Original\\query',color='reportgrey',fill=3,name='query')
f.box(132,92,94,44,r'Frozen SBERT\\+ CLIP text\\query vectors',name='encoder')
f.box(238,92,95,44,r'Exact retrieval\\Top100\\candidates',name='ret')
f.box(346,92,98,44,r'Prepared28\\original scaler',color='reportteal',name='features')
f.box(454,92,87,44,r'Frozen ListNet\\64 '+r'$\to$'+r' 32\\product scores',color='reportwarm',name='ranker')
for a,b in [('query','encoder'),('encoder','ret'),('ret','features'),('features','ranker')]:f.arrow('('+a+'.east)','('+b+'.west)')
f.add(r'\draw[-{Latex[length=3.4pt]},line width=.65pt,draw=black!65] (index.south)--(441,169)--(238,169)--(ret.north);')
f.arrow('(ranker.south)','(454,43)')
f.text(454,32,'Ranked products',r'font=\sffamily\bfseries\fontsize{8}{9.4}\selectfont')
f.text(0,36,'Frozen encoders, index, scaler and ranking weights','anchor=west,text=black!65')
f.text(0,19,'RRF60 and projection adaptation are separate evaluated alternatives.','anchor=west,text=black!65')
f.end('architecture.tex')
# 2. Orthogonal query/product partitions and explicit permitted roles.
f=Fig(253)
f.text(0,243,r'\textbf{a}\quad Independent frozen partitions',r'anchor=west,font=\sffamily\bfseries\fontsize{9}{10}\selectfont')
for y,label,parts in [(207,'Queries',[(.7,'Train','6,269','reportblue'),(.15,'Validation','1,344','reportteal'),(.15,'Test','1,343','reportwarm')]),(159,'Products',[(.8,'Warm','131,920','reportblue'),(.1,'Cold-Val','16,490','reportteal'),(.1,'Cold-Test','16,490','reportwarm')])]:
 f.text(0,y,label,r'anchor=west,font=\sffamily\bfseries\fontsize{8}{9.4}\selectfont');x=92
 for frac,role,n,c in parts:
  w=406*frac
  f.add(r'\filldraw[fill='+c+'!10,draw=white,line width=1pt] '+P(x,y-17)+' rectangle '+P(x+w,y+17)+';')
  f.text(x+w/2,y+6,role,r'font=\sffamily\fontsize{7.5}{8.8}\selectfont');f.text(x+w/2,y-6,n,r'font=\sffamily\fontsize{7.5}{8.8}\selectfont');x+=w
f.text(0,121,r'\textbf{b}\quad Supervision and evaluation roles',r'anchor=west,font=\sffamily\bfseries\fontsize{9}{10}\selectfont')
xs=[223,332,441]
for x,s in zip(xs,['Warm','Cold-Val','Cold-Test']):f.text(x,101,s,r'font=\sffamily\bfseries\fontsize{8}{9.4}\selectfont')
rows=[(78,'Supervised training',['Train labels','Excluded','Excluded']), (54,'Validation',['Development','Approved studies','Locked']), (30,'Final Test',['Evaluate','Masked','Evaluate'])]
for y,lab,entries in rows:
 f.text(0,y,lab,'anchor=west')
 for x,s in zip(xs,entries):
  color='reportblue' if s in ['Train labels','Evaluate','Development'] else 'reportwarm' if s=='Approved studies' else 'reportgrey'
  f.box(x,y,104,22,s,color=color,fill=6 if color!='reportgrey' else 2)
f.text(0,7,'All competitors remain; target labels are masked by scope. Predictions precede label unlock.',r'anchor=west,text=black!65,font=\sffamily\fontsize{7.5}{8.8}\selectfont')
f.end('protocol.tex')
# 3. Main paired Final Test effects with already-saved intervals.
matrel='output/final_report_evidence_audit_20261025/EVIDENCE_MATRIX.json';mat=load(matrel)
claim_index={c['claim_id']:i for i,c in enumerate(mat['claims'])}
contrasts=[('ESCI-TARGET-WEEK2','Week2 XGBoost '+r'$-$'+' BM25',198,True),('ESCI-TARGET-WEEK5','LambdaMART '+r'$-$'+' Week2 XGBoost',170,True),('ESCI-FINAL-COMP-LISTNET_VS_WEEK2','ListNet '+r'$-$'+' Week2 XGBoost',142,False),('ESCI-FINAL-COMP-LISTNET_VS_LAMBDAMART','ListNet '+r'$-$'+' LambdaMART',114,False),('ESCI-TARGET-WEEK6','ListNet '+r'$-$'+' Week2 XGBoost',61,True)]
f=Fig(244);x0,x1=204,445
px=lambda v:x0+(v+.02)/.08*(x1-x0)
f.text(0,230,r'\textbf{a}\quad Warm Test ($n=1,337$)',r'anchor=west,font=\sffamily\bfseries\fontsize{9}{10}\selectfont')
f.text(0,85,r'\textbf{b}\quad Cold-Test ($n=1,012$)',r'anchor=west,font=\sffamily\bfseries\fontsize{9}{10}\selectfont')
f.text(497,230,r'$\Delta$ NDCG@10','anchor=east')
f.line(px(0),45,px(0),216,'draw=black!40,dashed,line width=.65pt')
for ci,label,y,nested in contrasts:
 idx=claim_index[ci];base=f'/claims/{idx}/details/result'+('/paired' if nested else '')
 delta=val(matrel,base+'/delta');lo,hi=val(matrel,base+'/ci95');c='reportwarm' if 'WEEK6' in ci else 'reportblue'
 f.text(0,y,label,'anchor=west');f.line(px(lo),y,px(hi),y,'draw='+c+',line width=1.2pt');f.line(px(lo),y-3,px(lo),y+3,'draw='+c+',line width=.8pt');f.line(px(hi),y-3,px(hi),y+3,'draw='+c+',line width=.8pt');f.add(r'\fill['+c+'] '+P(px(delta),y)+' circle (2.9pt);');f.text(497,y,f'{delta:+.4f}','anchor=east,text='+c)
f.line(x0,37,x1,37)
for t in [-.02,0,.02,.04,.06]:
 x=px(t);f.line(x,37,x,34);f.text(x,26,f'{t:.2f}','text=black!65')
f.text((x0+x1)/2,8,'Absolute paired difference (95% CI)'.replace('%',r'\%'))
f.end('paired_effects.tex')
# 4. Cached core latency: log-axis points avoid a false log-bar baseline.
core='project/esci_sqid/outputs/week7_p2_v1/review/2026-10-19_f728b00ac1fd/results/benchmark_A.json'
session='20261020T014916_35f1b2c4';base='/by_session/'+session
f=Fig(208)
f.text(0,197,r'\textbf{a}\quad Cached-vector core',r'anchor=west,font=\sffamily\bfseries\fontsize{9}{10}\selectfont')
f.text(260,197,r'\textbf{b}\quad Component means',r'anchor=west,font=\sffamily\bfseries\fontsize{9}{10}\selectfont')
x0,x1=73,237;px=lambda v:x0+math.log(v/70)/math.log(3000/70)*(x1-x0)
for k,y in [('A0',155),('A1',119),('A2',83)]:
 mean=val(core,base+'/'+k+'/total_seconds/mean_ms');p95=val(core,base+'/'+k+'/total_seconds/p95_ms')
 f.text(1,y,k,r'anchor=west,font=\sffamily\bfseries\fontsize{8}{9.4}\selectfont');f.line(px(mean),y,px(p95),y,'draw=black!60,line width=1pt')
 f.add(r'\fill[reportblue] '+P(px(mean),y)+' circle (2.7pt);');x=px(p95);f.add(r'\fill[reportwarm] '+P(x,y+3.3)+'--'+P(x+3.3,y)+'--'+P(x,y-3.3)+'--'+P(x-3.3,y)+'--cycle;')
 f.text(43,y,{'A0':'Original','A1':'Prepared','A2':'+ key map'}[k],r'text=black!65,font=\sffamily\fontsize{7}{8}\selectfont')
f.line(px(200),63,px(200),174,'draw=black!45,dashed,line width=.5pt');f.text(px(200),181,'200 ms',r'font=\sffamily\fontsize{7.5}{8.5}\selectfont')
f.line(x0,61,x1,61)
for t in [100,200,500,1000,2000]:
 x=px(t);f.line(x,61,x,58);f.text(x,49,str(t),r'font=\sffamily\fontsize{7}{8}\selectfont')
f.text((x0+x1)/2,34,'Latency (ms, log scale)')
f.add(r'\fill[reportblue] (76,14) circle (2.5pt);');f.text(84,14,'Mean','anchor=west');f.add(r'\fill[reportwarm] (137,17)--(140,14)--(137,11)--(134,14)--cycle;');f.text(145,14,'P95','anchor=west')
x0,x1=333,488;px=lambda v:x0+math.log(v/.1)/math.log(3000/.1)*(x1-x0)
for label,stage,y in [('FAISS','faiss_native_seconds',155),('Key map','key_mapping_seconds',119),('Features','features_seconds',83)]:
 a=val(core,base+'/A0/'+stage+'/mean_ms');b=val(core,base+'/A2/'+stage+'/mean_ms');f.text(261,y,label,'anchor=west')
 f.line(px(a),y+2,px(b),y-2,'draw=black!50,line width=.7pt');f.add(r'\draw[draw=black!55,fill=white,line width=.8pt] '+P(px(a),y+2)+' circle (2.6pt);');x=px(b);f.add(r'\fill[reportblue] '+P(x,y+1.2)+'--'+P(x+3,y-4)+'--'+P(x-3,y-4)+'--cycle;')
f.line(x0,61,x1,61)
for t in [.1,1,10,100,1000]:
 x=px(t);f.line(x,61,x,58);f.text(x,49,str(t).removesuffix('.0'),r'font=\sffamily\fontsize{7}{8}\selectfont')
f.text((x0+x1)/2,34,'Mean latency (ms, log scale)')
f.add(r'\draw[draw=black!55,fill=white,line width=.8pt] (348,14) circle (2.5pt);');f.text(356,14,'A0','anchor=west');f.add(r'\fill[reportblue] (413,17)--(416,12)--(410,12)--cycle;');f.text(421,14,'A2','anchor=west')
f.end('core_performance.tex')
# 5. Actual saved HTTP request latencies, never inferred from model scores.
reqrel='output/week7_queue64/runs/20261023T184900Z_candidate64_cache8192/REQUESTS.json';requests=load(reqrel)
f=Fig(221);x0,x1,y0,y1=48,475,42,177;px=lambda v:x0+v/10*(x1-x0);py=lambda v:y0+v*(y1-y0)
for t in [0,.25,.5,.75,1]:
 y=py(t);f.line(x0,y,x1,y,'draw=black!12,line width=.4pt');f.text(x0-7,y,f'{t:.2f}'.rstrip('0').rstrip('.'),'anchor=east')
f.line(x0,y1,x0,y0);f.line(x0,y0,x1,y0)
for t in [0,2,4,6,8,10]:
 x=px(t);f.line(x,y0,x,y0-3);f.text(x,y0-12,str(t))
f.text((x0+x1)/2,8,'Loopback HTTP latency (s)');f.text(10,(y0+y1)/2,'Empirical cumulative probability','rotate=90')
f.line(px(10),y0,px(10),y1,'draw=black!40,densely dotted,line width=.6pt');f.text(489,(y0+y1)/2,'10 s response limit',r'rotate=90,text=black!60,font=\sffamily\fontsize{7.5}{8.5}\selectfont')
cdf_summary={}
for k,phase,col,style,n,label,ly in [('burst','burst_64','reportblue','solid',640,'64-request bursts',208),('steady','steady_64','reportwarm','dashed',1413,'64-client closed loop',192)]:
 vals=sorted(float(x['http_ms'])/1000 for x in requests if x['phase']==phase and x['status']==200);assert len(vals)==n
 pts=[(0,0)]+[(x,(i+1)/n) for i,x in enumerate(vals)]+[(10,1)]
 f.add(r'\draw[draw='+col+',line width=1.2pt,'+style+r'] plot[const plot] coordinates {'+' '.join(P(px(x),py(y)) for x,y in pts)+'};')
 f.line(49,ly,70,ly,'draw='+col+',line width=1.2pt,'+style);f.text(76,ly,label+f' ($n={n:,}$)','anchor=west')
 cdf_summary[phase]={'successful_requests':n,'source_filter':'status == 200','minimum_s':vals[0],'maximum_s':vals[-1],'all_sorted_latency_seconds':vals}
f.end('http_latency_cdf.tex')
# 6. Training curves, same four original saved series and checkpoints.
t=json.loads((E/'training_curves_sources.json').read_text());series=t['series'];f=Fig(356)
def panel(letter,title,x0,y0,xlim,ylim,xt,yt,xlabel,ylabel,points,color,selected=None,reference=None):
 w,h=181,108;px=lambda v:x0+(v-xlim[0])/(xlim[1]-xlim[0])*w;py=lambda v:y0+(v-ylim[0])/(ylim[1]-ylim[0])*h
 f.text(x0-43,y0+h+23,r'\textbf{'+letter+r'}\quad '+title,r'anchor=west,font=\sffamily\bfseries\fontsize{9}{10}\selectfont')
 for yy,lab in yt:
  y=py(yy);f.line(x0,y,x0+w,y,'draw=black!12,line width=.4pt');f.text(x0-6,y,lab,'anchor=east')
 f.line(x0,y0+h,x0,y0);f.line(x0,y0,x0+w,y0)
 for xx,lab in xt:
  x=px(xx);f.line(x,y0,x,y0-3);f.text(x,y0-12,lab)
 f.text(x0+w/2,y0-29,xlabel);f.text(x0-39,y0+h/2,ylabel,'rotate=90')
 if reference:
  f.line(x0,py(reference),x0+w,py(reference),'draw=reportwarm,dashed,line width=.8pt');f.text(x0+w-2,py(reference)+7,'Frozen CLIP',r'anchor=east,text=reportwarm,font=\sffamily\fontsize{7.5}{8.5}\selectfont')
 f.add(r'\draw[draw='+color+',line width=1pt] '+'--'.join(P(px(x),py(y)) for x,y in points)+';')
 for x,y in points:f.add(r'\fill['+color+'] '+P(px(x),py(y))+' circle (1.9pt);')
 if selected is not None:
  x,y=next((x,y) for x,y in points if x==selected);f.add(r'\draw[draw=reportwarm,line width=1pt] '+P(px(x),py(y))+' circle (3.8pt);');f.text(x0+w-2,py(y)-14 if reference else y0+h-7,'Selected '+str(selected),r'anchor=east,text=reportwarm,fill=white,inner sep=1pt,font=\sffamily\fontsize{7.5}{8.5}\selectfont')
panel('a','LambdaMART',52,216,(0,300),(.692,.701),[(x,str(x)) for x in [0,100,200,300]],[(x,f'{x:.3f}') for x in [.692,.696,.700]],'Trees','Warm NDCG@10',series['lambdamart']['points'],'reportblue',selected=180)
panel('b','ListNet',307,216,(1,11),(.699,.706),[(x,str(x)) for x in [1,3,5,7,9,11]],[(x,f'{x:.3f}') for x in [.700,.702,.704,.706]],'Epoch','Warm NDCG@10',series['listnet']['points'],'reportblue',selected=6)
panel('c','Projection training',52,48,(1,5),(.35,1.05),[(x,str(x)) for x in range(1,6)],[(x,f'{x:.1f}') for x in [.4,.6,.8,1.]],'Epoch','Symmetric InfoNCE loss',series['projection_loss']['points'],'reportteal')
panel('d','Alignment validation',307,48,(1,5),(.818,.838),[(x,str(x)) for x in range(1,6)],[(x,f'{x:.3f}') for x in [.820,.825,.830,.835]],'Epoch','Mean bidirectional R@10',series['projection_alignment']['points'],'reportteal',selected=5,reference=series['projection_alignment']['frozen_reference'])
f.end('training_curves.tex')
# Extend provenance without changing archived metrics.
meta={'scope':'Visual redesign only. Existing point estimates, CIs, training histories and measured HTTP latencies. No training, inference, relevance labels or bootstrap execution.','sources':[dict(path=p,sha256=h) for p,h in sorted(SOURCES.items())],'values_with_pointers':VALUES,'cdf':cdf_summary,'training_series_source':'evidence/training_curves_sources.json','rendering':{'format':'native TikZ vector','figure_font_pt':10.2,'intended_display_width_in':5.5,'palette':'blue #0072B2, orange #D55E00, green #009E73, neutral gray','no_smoothing':True,'ci_intervals':'existing saved paired 95% intervals, not recomputed'},'figures':{name:hashlib.sha256((F/name).read_bytes()).hexdigest() for name in ['architecture.tex','protocol.tex','paired_effects.tex','core_performance.tex','http_latency_cdf.tex','training_curves.tex']}}
(E/'publication_figures_sources.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps({'figures':6,'saved_value_assertions':len(VALUES),'http_samples':sum(v['successful_requests'] for v in cdf_summary.values()),'source_files':len(SOURCES)}))
