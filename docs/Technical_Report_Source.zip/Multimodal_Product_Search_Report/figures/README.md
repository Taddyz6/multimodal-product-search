The report uses `architecture_user.png`, supplied by the user, for Figure 1. The original attachment is copied without editing. The previous editable architecture diagram (`architecture.tex` and `pdf/architecture.pdf`) is retained for reference.

# Publication-style figures

The remaining diagrams/charts use native editable TikZ vectors with consistent sans-serif labels, a colorblind-friendly blue/orange/green palette, restrained axes and explicit panel labels. Standalone vector PDFs are in `pdf/`.

- `architecture`: frozen catalog assets and query-time pipeline.
- `protocol`: independent query/product partitions and permitted roles.
- `paired_effects`: existing Final Test query-paired effect estimates and 95% intervals; no new bootstrap.
- `core_performance`: matched cached-vector mean/P95 and component means, with explicit log axes.
- `http_latency_cdf`: empirical distributions of the same saved 640 burst and 1,413 closed-loop successful requests.
- `training_curves`: exactly the original four saved checkpoint/epoch series, without smoothing.
- `search_demo.png`: unchanged actual browser screenshot, framed/cropped only in LaTeX.

`build_publication_figures.py` reads original saved results in the project workspace. It does not train models or perform relevance evaluation. `evidence/publication_figures_sources.json` records values, file hashes and the stored timing series. Compiling the report requires only the included generated TeX, not access to the experimental assets.
