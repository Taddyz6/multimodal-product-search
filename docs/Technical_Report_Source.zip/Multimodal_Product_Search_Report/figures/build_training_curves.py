#!/usr/bin/env python3
"""Draw saved histories as native TikZ. No model execution or new evaluation."""
from pathlib import Path
import json,hashlib,math
ROOT=Path(__file__).resolve().parents[4]
OUT=Path(__file__).resolve().parent
EVID=OUT.parent/'evidence'
W5='project/esci_sqid/outputs/week5/review/2026-10-14_855a1cc23de8/week5_results/models/full/'
W6='project/esci_sqid/outputs/week6/review/2026-10-15_83101a911b1b/week6_results/experiment_a/report.json'
DEP='output/final_report_evidence_audit_20261025/esci_core/frozen_dependency_map.json'
CACHE={};VALUES=[]
def read(path):
 if path not in CACHE:CACHE[path]=json.loads((ROOT/path).read_text())
 return CACHE[path]
def get(path,pointer):
 x=read(path)
 for part in pointer.strip('/').split('/') if pointer else []:
  x=x[int(part)] if isinstance(x,list) else x[part]
 VALUES.append({'source_path':path,'json_pointer':pointer,'value':x})
 return x
series={}
for name in ['lambdamart','listnet']:
 p=W5+name+'/model.json';h=read(p)['history'];points=[];loss=[]
 for i,_ in enumerate(h):
  step=get(p,f'/history/{i}/step');score=get(p,f'/history/{i}/warm_ndcg@10')
  points.append([step,score])
  if 'mean_loss' in h[i]:loss.append([step,get(p,f'/history/{i}/mean_loss')])
 selected=get(p,'/best_step')
 assert selected==max(points,key=lambda v:v[1])[0]
 assert get(p,'/config/patience')==5
 assert sum(1 for x,y in points if x>selected)==5
 series[name]={'points':points,'selected_step':selected,'selected_value':next(y for x,y in points if x==selected),'unit':'Warm Validation NDCG@10','train_loss_if_recorded':loss,'selected_by':get(p,'/selection')}
 # The original model metadata is registered in the frozen dependency map.
 records=read(DEP)['artifact_records'];record=next(r for r in records if r['path']==str(ROOT/p))
 assert hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==record['expected_sha256']
loss=[];align=[]
for i,row in enumerate(read(W6)['history']):
 epoch=get(W6,f'/history/{i}/epoch')
 loss.append([epoch,get(W6,f'/history/{i}/loss')])
 align.append([epoch,get(W6,f'/history/{i}/alignment/selection_mean_recall@10')])
selected=get(W6,'/selected_epoch');frozen=get(W6,'/frozen/selection_mean_recall@10')
assert len(loss)==5 and [r[0] for r in loss]==[1,2,3,4,5]
assert selected==max(align,key=lambda v:v[1])[0]==5
assert all(y<frozen for x,y in align)
assert align[-1][1]==get(W6,'/adapted/selection_mean_recall@10')
assert hashlib.sha256((ROOT/W6).read_bytes()).hexdigest()=='0c41d97993ece815865519535ae01d3d07b554512b188271a6d0f69adcd02def'
series['projection_loss']={'points':loss,'unit':'Training symmetric InfoNCE loss'}
series['projection_alignment']={'points':align,'unit':'Warm Validation mean bidirectional Recall@10','selected_epoch':selected,'frozen_reference':frozen,'gallery_products':get(W6,'/frozen/products')}
# Manual native TikZ axes avoid a pgfplots dependency and keep all labels editable.
lines=[r'% Generated from saved histories by figures/build_training_curves.py.',r'% Caption: Saved development training and validation histories. Selected checkpoints are circled; the frozen CLIP reference is dashed. Each panel has its own units and scale.',r'\begin{tikzpicture}[x=1pt,y=1pt,font=\footnotesize]',r'\path[use as bounding box] (0,0) rectangle (500,360);']
def emit(s):lines.append(s)
def fmt(v):return f'{v:.3f}'
def point(x,y):return f'({x:.3f},{y:.3f})'
def panel(title,x0,y0,w,h,xmin,xmax,ymin,ymax,xticks,yticks,xlabel,ylabel,points,color='reportblue',selected=None,reference=None):
 def px(v):return x0+(v-xmin)/(xmax-xmin)*w
 def py(v):return y0+(v-ymin)/(ymax-ymin)*h
 emit(r'\node[anchor=west,font=\small] at '+point(x0-45,y0+h+28)+' {'+title+'};')
 for x,label in xticks:
  emit(r'\draw[reportlight!65,line width=.3pt] '+point(px(x),y0)+'--'+point(px(x),y0+h)+';')
  emit(r'\node[text=reportgrey,anchor=north] at '+point(px(x),y0-5)+' {'+label+'};')
 for y,label in yticks:
  emit(r'\draw[reportlight!65,line width=.3pt] '+point(x0,py(y))+'--'+point(x0+w,py(y))+';')
  emit(r'\node[text=reportgrey,anchor=east] at '+point(x0-5,py(y))+' {'+label+'};')
 emit(r'\draw[reportgrey,line width=.5pt] '+point(x0,y0+h)+'--'+point(x0,y0)+'--'+point(x0+w,y0)+';')
 emit(r'\node at '+point(x0+w/2,y0-32)+' {'+xlabel+'};')
 emit(r'\node[rotate=90] at '+point(x0-37,y0+h/2)+' {'+ylabel+'};')
 if reference:
  v,label=reference;emit(r'\draw[dashed,reportwarm,line width=.9pt] '+point(x0,py(v))+'--'+point(x0+w,py(v))+';')
  emit(r'\node[anchor=south west,text=reportwarm,fill=white,inner sep=1pt] at '+point(x0+3,py(v)+1)+' {'+label+'};')
 emit(r'\draw['+color+r',line width=1pt] '+'--'.join(point(px(x),py(y)) for x,y in points)+';')
 for x,y in points:emit(r'\fill['+color+'] '+point(px(x),py(y))+' circle (1.6pt);')
 if selected is not None:
  x,y=next((x,y) for x,y in points if x==selected)
  emit(r'\draw[reportwarm,line width=1.1pt] '+point(px(x),py(y))+' circle (3.6pt);')
  emit(r'\node[anchor=north east,text=reportwarm,fill=white,inner sep=1pt] at '+point(x0+w-1,y0+h-2)+' {selected '+str(selected)+'};')
panel('(a) Week5 LambdaMART',45,222,185,100,0,300,.692,.701,[(0,'0'),(100,'100'),(200,'200'),(300,'300')],[(.692,'.692'),(.696,'.696'),(.700,'.700')],'Checkpoint (trees)','Warm Val NDCG@10',series['lambdamart']['points'],selected=series['lambdamart']['selected_step'])
panel('(b) Week5 ListNet',300,222,185,100,1,11,.699,.706,[(1,'1'),(3,'3'),(5,'5'),(7,'7'),(9,'9'),(11,'11')],[(.700,'.700'),(.702,'.702'),(.704,'.704'),(.706,'.706')],'Epoch','Warm Val NDCG@10',series['listnet']['points'],selected=series['listnet']['selected_step'])
panel('(c) Week6 projection training',45,54,185,100,1,5,.35,1.05,[(i,str(i)) for i in range(1,6)],[(.4,'.4'),(.6,'.6'),(.8,'.8'),(1.0,'1.0')],'Epoch','Training InfoNCE loss',loss,color='reportteal')
panel('(d) Week6 alignment validation',300,54,185,100,1,5,.818,.838,[(i,str(i)) for i in range(1,6)],[(.820,'.820'),(.825,'.825'),(.830,'.830'),(.835,'.835')],'Epoch','Mean bidirectional R@10',align,color='reportteal',selected=selected,reference=(frozen,'frozen '+f'{frozen:.4f}'))
emit(r'\end{tikzpicture}')
(OUT/'training_curves.tex').write_text('\n'.join(lines)+'\n')
for v in VALUES:
 x=read(v['source_path'])
 for k in v['json_pointer'].strip('/').split('/'):
  x=x[int(k)] if isinstance(x,list) else x[k]
 assert x==v['value']
provenance={'boundary':'Saved histories/configuration only. No model, vector, raw relevance, new metric, bootstrap or timing execution. Coordinates are linear display transforms of saved values.','figure':'figures/training_curves.tex','claim_ids':['ESCI-W5-001','ESCI-W5-002','ESCI-W6-001','ESCI-W6-002','OPT-W6-ALIGN'],'sources':[{'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()} for p in sorted(CACHE)],'values_with_pointers':VALUES,'series':series,'observations':['LambdaMART reaches its saved validation maximum at checkpoint 180, then records five lower checks through 280; this matches the saved patience=5 setting.','ListNet reaches its saved validation maximum at epoch 6; the next five recorded epochs are lower while training loss finishes lower. This supports the stopping rationale; a single run cannot distinguish overfitting from validation noise or establish seed stability.','Week6 loss decreases through five epochs, and alignment mean Recall@10 rises across those recorded epochs. Every adapted checkpoint remains below the frozen reference; epoch 5 is the best adapted checkpoint, not a successful improvement over frozen CLIP.','No LambdaMART training-loss series is present in its saved model metadata, so none is drawn. The figure shows only recorded checkpoints; no interpolation is claimed beyond lines connecting them.'],'verification':{'all_pointer_assertions_passed':True,'pointer_values':len(VALUES),'week5_model_metadata_matches_frozen_registered_sha256':True,'week6_experiment_report_matches_audit_registered_sha256':True}}
(EVID/'training_curves_sources.json').write_text(json.dumps(provenance,indent=2)+'\n')
print(json.dumps({'generated':'figures/training_curves.tex','verified_pointer_values':len(VALUES),'files_hashed':len(CACHE)}))
