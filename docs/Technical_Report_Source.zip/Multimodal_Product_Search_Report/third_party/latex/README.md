# Bundled LaTeX dependencies

The report root contains the user-provided NeurIPS-derived style (original attribution retained), titlesec, nicefrac and required Helvetica Type 1 metrics/font files. No system installation is required for these bundled files.

- `titlesec.zip`: original CTAN titlesec source distribution (MIT; see package headers and README).
- `units.zip`: original CTAN units/nicefrac source distribution; includes `units.dtx`, `units.ins` and the GNU GPL license in `COPYING`.
- `helvetic.tar.xz`: original TeX Live helvetic distribution; license metadata is in `helvetic/tlpkg/tlpobj/helvetic.tlpobj`.

The source archives are retained without modification. Native TeX Live still supplies the standard packages and Times/Latin Modern/math fonts listed in the report README.
