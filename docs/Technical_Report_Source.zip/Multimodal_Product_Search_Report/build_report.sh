#!/bin/sh
set -eu
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
mkdir -p build
PDFLATEX=${PDFLATEX:-pdflatex}
BIBTEX=${BIBTEX:-bibtex}
"$PDFLATEX" -interaction=nonstopmode -halt-on-error -file-line-error -output-directory=build Multimodal_Product_Search_Report.tex
"$BIBTEX" build/Multimodal_Product_Search_Report
"$PDFLATEX" -interaction=nonstopmode -halt-on-error -file-line-error -output-directory=build Multimodal_Product_Search_Report.tex
"$PDFLATEX" -interaction=nonstopmode -halt-on-error -file-line-error -output-directory=build Multimodal_Product_Search_Report.tex
