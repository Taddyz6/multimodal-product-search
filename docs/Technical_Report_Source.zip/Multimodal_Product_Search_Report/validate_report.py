"""Read-only report/evidence checks. Does not load labels or execute any model."""
from pathlib import Path
import hashlib,json,re
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parent
WORKSPACE=ROOT.parents[2]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pointer(obj,path):
    for part in path.split('/')[1:]:
        part=part.replace('~1','/').replace('~0','~')
        obj=obj[int(part)] if isinstance(obj,list) else obj[part]
    return obj
loaded={}
def src(path):
    p=Path(path)
    return p if p.is_absolute() else WORKSPACE/p
count=0
for name,files_key,values_key in [('tables_sources.json','source_files','cell_sources'),('training_curves_sources.json','sources','values_with_pointers'),('publication_figures_sources.json','sources','values_with_pointers')]:
    data=json.loads((ROOT/'evidence'/name).read_text())
    for entry in data[files_key]:
        p=src(entry['path']);assert p.is_file(),p
        assert sha(p)==entry['sha256'],str(p)+' hash changed'
    for entry in data[values_key]:
        p=src(entry['source_path'])
        if p not in loaded:loaded[p]=json.loads(p.read_text())
        assert pointer(loaded[p],entry['json_pointer'])==entry['value'],entry
        count+=1
pdf_path=ROOT/'build/Multimodal_Product_Search_Report.pdf';reader=PdfReader(pdf_path)
text='\n'.join(p.extract_text() for p in reader.pages)
log=(ROOT/'build/Multimodal_Product_Search_Report.log').read_text(errors='replace')
assert len(reader.pages)==38
assert not reader.is_encrypted
assert '??' not in text and '\ufffd' not in text
assert 'mmpsr' not in text.casefold()
assert 'mmpsr' not in str(reader.metadata).casefold()
assert reader.metadata.title=='Multimodal Product Search: Retrieval, Ranking, and System Optimization'
assert reader.metadata.author=='Junhao Zhang'
for phrase in ['Junhao Zhang','Department of ECE','junhaoz@andrew.cmu.edu']:
    assert phrase in reader.pages[0].extract_text(),phrase
assert 'Human-Judged Evaluation' not in reader.metadata.title
for phrase in ['Annotation Quality and Ambiguous Relevance','Week2: Learned Patterns','Week3: Intent Preservation','Week5: Fine-Grained','Week6: Unseen Products','32B','SFT','reinforcement learning']:
    assert phrase in text,phrase
for bad in ['Overfull \\hbox','Overfull \\vbox','Underfull \\hbox','Underfull \\vbox','undefined references','undefined citations','LaTeX Warning:','Package natbib Warning:','! LaTeX Error']:
    assert bad not in log,bad
main=(ROOT/'Multimodal_Product_Search_Report.tex').read_text()
for required in [r'\documentclass{article}',r'\PassOptionsToPackage{numbers,square,sort&compress}{natbib}',r'\usepackage[final]{style}',r'\maketitle',r'\bibliographystyle{unsrtnat}']:
    assert required in main,required
assert all((ROOT/name).is_file() for name in ['style.sty','nicefrac.sty','titlesec.sty'])
table_values_unchanged=0
old_tables=ROOT/'revisions/20261026_before_template/tables'
if old_tables.is_dir():
    for old in sorted(old_tables.glob('*.tex')):
        if old.name.endswith('_qa.tex'):continue
        rows=lambda p:[line.strip() for line in p.read_text().splitlines() if ' & ' in line and line.rstrip().endswith(r'\\')]
        assert rows(old)==rows(ROOT/'tables'/old.name),old.name
        table_values_unchanged+=1
tex_files=[ROOT/'Multimodal_Product_Search_Report.tex',*sorted((ROOT/'sections').glob('*.tex')),*sorted((ROOT/'appendix').glob('*.tex')),*sorted((ROOT/'tables').glob('*.tex')),*sorted((ROOT/'figures').glob('*.tex'))]
tex_files=[p for p in tex_files if not p.name.endswith('_qa.tex')]
source='\n'.join(p.read_text() for p in tex_files)
labels=re.findall(r'\\label\{([^}]+)\}',source)
# Table labels provided through the report macro.
labels+=re.findall(r'\\tableinput\{[^}]+\}\{[^}]+\}\{([^}]+)\}',source)
assert len(labels)==len(set(labels)), 'duplicate labels'
refs=re.findall(r'\\(?:ref|eqref)\{([^}]+)\}',source)
assert not (set(refs)-set(labels)),set(refs)-set(labels)
bib=(ROOT/'references.bib').read_text();keys=set(re.findall(r'@\w+\{([^,]+),',bib))
cites=set()
for group in re.findall(r'\\cite\w*\{([^}]+)\}',source):cites.update(group.split(','))
assert not(cites-keys),cites-keys
assert len(re.findall(r'\\bibitem', (ROOT/'build/Multimodal_Product_Search_Report.bbl').read_text()))==len(cites)
assert not re.search(r'@(?:techreport|book|manual|online)\{',bib,re.I)
assert not re.search(r'@\w+\{(?:minilm_model|bge_model|bge_reranker_model|qwen_model|qwen25_model|qwen_reranker_model|faiss_indexes|fastapi_docs|streamlit_docs),',bib)
expected_features=['bm25','tfidf','title_tfidf','query_coverage','title_coverage','brand_overlap','color_overlap','bullet_coverage','description_coverage','digit_coverage','has_digits','title_phrase_match','brand_phrase_match','query_length','title_length','document_length','missing_description','missing_bullet','missing_brand','missing_color','sbert_similarity','clip_text_similarity','clip_image_similarity','image_available','calibrated_text_fusion_score','calibrated_fusion_score','brand_length','color_length']
feature_table=(ROOT/'appendix/technical_details.tex').read_text()
assert re.findall(r'^\d+ & \\feature\{([^}]+)\}',feature_table,re.M)==expected_features
for phrase in ['102.16','164.03','184.52','204.99','337.10','370.08','69,036','470.97','294.11','closed-loop','two-pass','Final Test','known-positive','Cold-Test','MAP@10','MRR','Prediction Lock','0.7163','0.3247','14.35','94.93','113.35','640/640','1,413/1,413','References','Archived error examples']:
    assert phrase in text,phrase
figures=[ROOT/'figures'/n for n in ['architecture_user.png','protocol.tex','core_performance.tex','http_latency_cdf.tex','training_curves.tex','paired_effects.tex','search_demo.png','local_latency_repeats.tex']]
assert all(p.is_file() and p.stat().st_size for p in figures)
assert r'\includegraphics[width=\linewidth]{figures/architecture_user.png}' in (ROOT/'sections/03_methodology.tex').read_text()
assert sha(ROOT/'figures/architecture_user.png')==json.loads((ROOT/'evidence/ARCHITECTURE_FIGURE_REPLACEMENT.json').read_text())['source_sha256']
qa=ROOT/'build/qa_references_20261029'
assert len(list(qa.glob('page-*.png')))==len(reader.pages)

# Independent report-level checks for every new repeated-performance row.
new_evidence=json.loads((ROOT/'evidence/WEEK8_PERFORMANCE_AMENDMENT.json').read_text())
local_path=ROOT/'evidence/week7_local_revalidation/DESCRIPTIVE_RECOMPUTATION.json'
assert sha(local_path)==new_evidence['source_sha256']
local=json.loads(local_path.read_text());new_rows=0
norm=lambda s:re.sub(r'\s+','',s)
def check_new_rows(name,expected):
    global new_rows
    actual=[line.strip() for line in (ROOT/'tables'/name).read_text().splitlines() if ' & ' in line and line.rstrip().endswith(r'\\')][1:]
    assert [norm(x) for x in actual]==[norm(' & '.join(x)+r' \\') for x in expected],name
    new_rows+=len(expected)
f=lambda x:f'{x:.2f}'
rows=[]
for name,label in [('A2_extended','A: cached vectors'),('B_online','B: live encoders'),('C_sequential','C: complete HTTP')]:
    a=local['aggregates'][name];s=a['pooled_complete_load_stats']
    rows.append([label,'4','4,000',f(a['mean_of_repeat_means'])+r' $\pm$ '+f(a['sample_sd']),f(s['p95']),f(s['p99']),f"{s['under200']*100:.2f}\\%"])
check_new_rows('local_serial.tex',rows)
rows=[]
for n in range(1,5):
    row=[str(n)]
    for name in ['A2_extended','B_online','C_sequential']:
        s=next(x for x in local['scenes'] if x['repeat']==n and x['scene']==name)['stats'];row.append(f(s['mean'])+' / '+f(s['p95']))
    rows.append(row)
check_new_rows('local_repeat_detail.tex',rows)
rows=[];summary=[]
for name,label in [('burst_hot','Hot burst'),('burst_broad','Broad burst'),('sustained_hot','Hot sustained'),('sustained_broad','Broad sustained')]:
    for s in [x for x in local['scenes'] if x['scene']==name]:
        st=s['statuses'];rows.append([label,str(s['repeat']),f"{s['stats']['n']:,}",f"{st.get('200',0):,} / {st.get('504',0):,}",f(s['stats']['mean']/1000)+' / '+f(s['stats']['p95']/1000),f(s['issue_window_s']),'Yes' if s['load_complete'] else 'No'])
    a=local['aggregates'][name];s=a['pooled_complete_load_stats'];summary.append([label,str(a['number_of_complete_repeats']),f(a['mean_of_repeat_means']/1000)+r' $\pm$ '+f(a['sample_sd']/1000),f(s['p95']/1000),f(s['p99']/1000)])
check_new_rows('local_concurrency.tex',rows);check_new_rows('local_concurrency_summary.tex',summary)
assert new_rows==27

result={'passed':True,'visible_personal_acronym_removed':True,'revision':'papers_only_references_20261029','title_verified':True,'author_block_verified':True,'citation_style':'numeric square sorted compressed','compiler':'pdfLaTeX + BibTeX','bundled_style':True,'table_fragments_with_unchanged_row_values':table_values_unchanged,'boundary':'Report verification only: saved JSON pointers/hashes, LaTeX/citations, PDF completeness and feature contract. No model, raw labels, bootstrap, inference or new benchmark.', 'new_local_performance_table_rows_checked':new_rows,'pdf_pages':len(reader.pages),'table_fragments':len([p for p in (ROOT/'tables').glob('*.tex') if not p.name.endswith('_qa.tex')]),'source_pointer_assertions':count,'distinct_json_sources':len(loaded),'reference_entries':len(keys),'cited_entries':len(cites),'feature_order_count':len(expected_features),'figures':len(figures),'undefined_references':0,'undefined_citations':0,'overfull_boxes':0,'underfull_boxes':0,'latex_warnings':0,'pdf_sha256':sha(pdf_path),'all_pages_rendered_and_visually_reviewed':True,'user_supplied_architecture_sha256':sha(ROOT/'figures/architecture_user.png'),'dense_pages_inspected_at_original_resolution':[1,3,17,18,19,22,35,36,38]}
(ROOT/'evidence/FINAL_REPORT_VALIDATION.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
