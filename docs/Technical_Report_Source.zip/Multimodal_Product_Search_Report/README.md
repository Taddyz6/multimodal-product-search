# Multimodal product search final technical report

This source project accompanies **Multimodal Product Search: Retrieval, Ranking, and System Optimization**, by Junhao Zhang, Department of ECE, junhaoz@andrew.cmu.edu. It uses the user-provided NeurIPS 2019-derived `style.sty` with the `final` layout option. That option controls formatting; no conference submission or acceptance is claimed.

## Build

Requirements: pdfLaTeX, BibTeX and standard TeX Live packages including fix-cm, Latin Modern Mono, amsmath, amssymb, booktabs, tabularx, longtable, array, graphicx, xcolor, TikZ, microtype, caption, natbib and hyperref. The requested `style.sty`, `titlesec.sty`, `nicefrac.sty`, and Helvetica font files are bundled in the project root. Their source archives and license information are in `third_party/latex/`. Citations use numeric, square, sorted and compressed references.

Run `sh ./build_report.sh`. Output: `build/Multimodal_Product_Search_Report.pdf`. `main.tex` also opens the report in the built-in LaTeX editor. The actual document is `Multimodal_Product_Search_Report.tex`.

## Evidence and scope

The report follows the approved evidence audit and outline in `evidence/`. Tables were extracted from archived result/configuration aggregates with exact JSON-pointer and SHA256 mapping in `evidence/tables_sources.json`. Figure source values and literature verification are also included. `evidence/final_test_metrics.csv` preserves the extended saved metric/CI ledger. The main text distinguishes fixed judged-pool NDCG, catalog known-positive recall, and engineering/HTTP timing.

Report preparation performed no training, model inference, tuning, raw-label evaluation, or new performance test run. Existing weekly code, results, models, indices, scalers, and labels were not edited. Model/data files and access credentials are deliberately absent from this archive. Table builders use original workspace source paths for provenance; the generated TeX can be compiled independently without those experiment assets.

## Contents

- `Multimodal_Product_Search_Report.tex`, `sections/`, `appendix/`: complete report source.
- `references.bib`: public academic papers; formal publication versions are preferred. Internal reports, model cards, repositories and tool documentation are excluded.
- `tables/`: generated, scope-labeled tables plus source-driven builder/index.
- `figures/`: the user-supplied system architecture image, native vector charts and an actual English UI screenshot.
- `evidence/`: numeric/source mapping, evidence audit, verification and review records.
- `build_report.sh`: deterministic local LaTeX build sequence.

The report preserves unmet targets, unadopted experiments, the live encoder compatibility/historical identity distinction, and finite-workload service limitations. It does not switch the frozen system in response to Final Test.

## Publication-style revision

The 38-page report uses the requested article preamble, title and author block, with subsection spacing of 0.4em before and 0.2em after headings. It contains the user-supplied architecture image, five native vector figures and the actual UI screenshot. Standalone vector PDFs are included in `figures/pdf/`; the prior editable architecture vector is retained as an archived alternative. Existing table values and model results are unchanged. The effect plot uses existing saved paired intervals; it is not a new experiment.

The hard-case discussion separates observed failures, plausible mechanisms and proposed follow-up work. A 32B annotator, SFT rewriting and online reinforcement learning are future proposals; no new experiments are reported.

## Week8 performance revision (2026-10-29)

The report now includes four actual local A/B/C repeats (4,000 observations per boundary), Hot/Broad Burst and Sustained tests, two-pass product-cache preparation, per-repeat means/variation, and all observed failures. The interrupted five-repeat plan is not claimed complete. Earlier finite-workload successes remain separately identified. The previous report/PDF/source ZIP are preserved in `revisions/20261029_before_week8_performance/`. New evidence is registered in `evidence/WEEK8_PERFORMANCE_AMENDMENT.json` and `evidence/week7_local_revalidation/`. Slides and demo video are deferred. A local GitHub source package is prepared separately; no remote publication or new-machine model runtime is claimed.

## References-only revision (2026-10-29)

Both final reports follow `REFERENCE_POLICY.md`. Internal project reports, the project outline, repository, model cards and API documentation are excluded from References. Published versions are used for XGBoost, ListNet, SQID, FAISS and LLM-as-a-Judge; the necessary ESCI dataset preprint is explicitly labeled. Evidence manifests remain separate historical provenance records. No experimental values changed.

## AI assistance appendix (2026-11-03)

A brief final appendix describes AI assistance with code scaffolding, debugging,
code review, organizing research ideas and experimental workflows, and documentation.
It does not change the methods, experimental results, or references. The prior
PDF and source archive are preserved in `revisions/20261103_before_ai_assistance_appendix/`.
