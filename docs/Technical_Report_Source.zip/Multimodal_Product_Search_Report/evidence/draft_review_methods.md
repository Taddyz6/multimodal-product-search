# Draft review: abstract, introduction, related work, methods, and setup

Reviewed the five requested section files against the approved outline, claim ledgers, aggregate audit artifacts, and implementation sources. This review did not read raw relevance tables, rerun a benchmark, train models, or edit report prose. Locations refer to the initially reviewed draft; quoted phrases provide anchors if concurrent edits move lines.

## Findings

### M1 — P2: Bound the DCG sum by the actual list length

**Location:** `sections/04_setup.tex:24`, `\sum_{r=1}^{10}`.

The candidate pool is not always at least ten items long: `project/esci_sqid/outputs/phase1/data_audit.json`, `/totals/candidates_per_query/min`, is **8**. Thus the displayed expression refers to undefined ranked products for some queries. The evaluator explicitly slices to the actual returned length (`project/esci_sqid/final_test_v1/protocol.py:93–97`). Use `min(10, |\mathcal J_q|)` as the upper limit or explicitly define zero-gain padded positions. This is a presentation error; the implementation handles short lists.

### M2 — P2: Define the membership of Overall explicitly

**Location:** `sections/04_setup.tex:22–27`, target scope `$S$` and “Warm, Cold-Test, and Overall.”

The section defines an abstract scope but never explicitly sets Overall to **Warm union Cold-Test**. That boundary matters because Cold-Val products retain candidate positions while their judgments are excluded from final evaluation. Add the three scope definitions near the metric definition, especially `S_Overall = Warm \cup Cold-Test`. Supported by `ESCI-METRIC-001`, `ESCI-FINAL-003`, and final evaluator label validation (`project/esci_sqid/final_test_v1/protocol.py:50–55`). The surrounding prose is consistent with the right protocol; the mathematical definition remains implicit.

### M3 — P2: Restrict the blanket aggregation statement

**Location:** `sections/04_setup.tex:35`, “All reported ranking and recall aggregates are query macros.”

P2 and targeted studies explicitly distinguish query macros from **unweighted means across folds**. For example, `project/esci_sqid/src/p2_protocol.py:43–47` stores both `fold_mean_delta` and `query_macro_delta`; `src/p2_cv.py:90–92` stores both fold means and query macros; `src/targeted_protocol.py:56–70` does the same. The current blanket assertion is inaccurate if the report includes the planned fold-mean optimization tables. State that the base/final metric summaries are query macros and that cross-validation fold means are separately labeled.

### M4 — P2: Describe historical supervision as weak/silver, not entirely Qwen-generated

**Location:** `sections/04_setup.tex:7`, “replacing the Qwen-generated training/test labels of the earlier metadata pipeline.”

Historical training was not entirely Qwen-generated. `project/final100k_src/benchmark_v2.py:254–258` selects Qwen grades when available and aligned rule grades otherwise, marking the source as `qwen_format_audited` or `rule_weak`. The adopted upgraded Week2 model explicitly trains on this mixed policy (`src/week2_upgrade_v2.py:41–46,59`). The introduction already describes rule-based or Qwen-generated labels accurately. A precise replacement is “replacing the earlier weak and silver supervision,” with the historical subsection explaining the mixture. This does not affect the statement that the ESCI benchmark uses released human judgments.

### M5 — P3: State the CLIP text input and normalization alongside the vector definitions

**Location:** `sections/03_methodology.tex:13`, the SBERT/CLIP vector definitions.

The paragraph states that SBERT encodes the five-field document and is normalized, but does not say that SQID CLIP product text encodes **the title only**, or explicitly state that CLIP vectors are L2-normalized before the dot products are treated as cosines. These details help readers interpret semantic/image comparisons. The approved audit flags the unmatched input scope (`ESCI-W4-001`); `project/esci_sqid/src/data/load_esci.py:13,78` defines the five-field SBERT document, `src/data/load_sqid.py:34–36,80` normalizes CLIP vectors, and `src/week4_data.py:31,54–56` validates that contract. SQID's primary paper and repository independently identify title-based CLIP text features (see `reference_verification.json`).

### M6 — P3: Define the remaining loss notation

**Location:** `sections/03_methodology.tex:39–53`.

`\mathcal Q` appears in the ListNet loss denominator without a definition, and `B` appears in the alignment loss without an explicit batch-size definition. Define `\mathcal Q` as the eligible training-query set (or the minibatch query set when describing the actual stochastic loss), explicitly write the query summation domain, and define `B` as the number of image–text product pairs in a batch. `L_q` is already defined correctly. These are notation clarifications, not changes to the implemented objectives.

## Optional precision improvements

- In `sections/02_related_work.tex:6`, “ListNet instead matches distributions over complete query lists” can be read as full permutation-distribution matching. “Top-one probability distributions over items within each query list” describes the actual original ListNet loss more precisely; the methodology's softmax equations are already correct.
- In `sections/03_methodology.tex:48–54` or the setup paragraph on projection training, state that the selected adapter checkpoint maximizes **Warm-Val mean bidirectional alignment Recall@10**. This is explicit in `project/esci_sqid/src/week6_alignment.py:73–77`. The current text correctly separates training and held-out pairs but leaves this selection criterion to the appendix.

## Checks without an actionable discrepancy

- Calibration equations match `week4_calibration.py`: available-image standardization, correlation-dependent mixture scale, missing-text variance correction, and text-distribution anchoring.
- The affine fused index expression has the correct coefficients and dimension: `384 + 768 + 1 = 1,153`. The implementation does not renormalize the concatenated vectors.
- Top100 retrieval and canonical tie resolution, including a boundary-tie range search, match `week4_vectors.py:38–54` and `week7_p2/retriever.py:60–87`.
- The eight additional ranking features, masked image feature, raw text-only fusion feature, grade-softmax ListNet target, MLP, and float64-statistics/float32-output scaler description match `week5_features.py` and `week5_models.py`.
- LambdaMART gains `0/1/3/7`, E/S positive eligibility, MAP denominator, full-list MRR, and preservation of competitor positions match the evaluated metric contract. The original ESCI gain convention is distinguished correctly.
- The two identity-initialized, bias-free projection heads and symmetric InfoNCE equation match `week6_alignment.py:17–40`; the adapter is correctly described as unadopted.
- No unsupported ranking superiority, image-only causal attribution, official ESCI leaderboard status, successful Cold adapter, approximate-nearest-neighbor contribution, or production-readiness claim was identified in the reviewed sections.
- Abstract ranking gains and same-session cached-core latency figures match the approved audit. The draft keeps core and live HTTP scopes distinct.

Review outcome: no blocking implementation/formula discrepancy found; address M1–M4 before freezing the report and consider M5–M6 for methodological completeness.
