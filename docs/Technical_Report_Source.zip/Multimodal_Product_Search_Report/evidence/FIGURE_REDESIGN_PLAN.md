# Figure and naming revision

User request: remove the personal project acronym from the report and make figures read like published research figures.

- Replace visible acronym/title branding with a neutral descriptive title.
- Preserve all source data, model identities, metric scopes, claims and historical experiment files.
- Redraw native vector figures with consistent sans-serif labels, colorblind-friendly colors, restrained borders, aligned panels, unambiguous arrows, explicit axes/units and appropriate legends.
- Make query and product partitions orthogonal in the protocol figure, rather than implying exclusive pairings between query and product roles.
- Add a paired Final Test effect/95% CI plot from existing saved comparisons; no bootstrap or experiment rerun.
- Keep the actual UI screenshot as functional evidence, not synthetic product or benchmark imagery.
- Use the CLIP published approach figure as a reference for modular visual explanation only; no copied content or architecture claims. Primary reference: https://proceedings.mlr.press/v139/radford21a/radford21a.pdf . SQID context: https://arxiv.org/pdf/2405.15190 .
- Compile and inspect every page after revision; export a neutrally named PDF and complete source archive.
