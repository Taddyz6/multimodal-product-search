# Week8 evidence addendum

This amendment uses the already audited local records from 2026-10-28–29. It adds no model execution or relevance evaluation.

| Item | Classification | Report use | Evidence |
|---|---|---|---|
| Actual four-repeat A/B/C measurement | Verified and completed | Results | local_serial/local_repeat_detail tables; copied raw recomputation and table crosscheck |
| Hot/Broad burst and sustained outcomes, including failures | Verified and completed | Results/Discussion | local_concurrency table; 57 observed scenes, 69,036 terminal HTTP records |
| Mean cached-core below200ms with P95 above200ms | Verified and completed | Results with explicit timing boundary | 102.16ms mean,204.99ms pooled P95 |
| Complete five-repeat certification | Blocked or unresolved | Scope limitation only | Interrupted fourth repeat; fifth absent; never claimed complete |
| Portable source/configuration package | Implemented but not fully evaluated | Reproduction documentation | Frozen312-file runtime;33 asset-free tests; no relocated full-asset run |
| Remote GitHub publication, slides and video | Proposed but not implemented | Delivery checklist | Not uploaded; slides/video explicitly deferred |

Earlier640/640 and1,413/1,413 successes remain valid finite-working-set measurements. They no longer support an unqualified stable64-client claim after broader repeated failures. Offline Final Test results, models, labels, feature definitions, historical tables and the supplied architecture image are unchanged.
