"""Second calculation using the standard library and raw serial records."""
from pathlib import Path
from collections import Counter
import csv,hashlib,json,math,statistics
OUT=Path(__file__).resolve().parent
ROOT=Path('/Users/zhangjunhao/Desktop/MMPSR')
d=json.loads((OUT/'DESCRIPTIVE_RECOMPUTATION.json').read_text());run=Path(d['source_attempt'])
def sha(p):
    with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def records(p):
    with p.open() as f:
        for s in f:
            if s.strip():yield json.loads(s)
def quantile(a,p):
    a=sorted(a);index=(len(a)-1)*p;low=math.floor(index);high=math.ceil(index)
    return a[low]+(a[high]-a[low])*(index-low)
totals=Counter();checks=[]
for name in ['A2_extended','B_online','C_sequential']:
    pooled=[];means=[]
    for n in range(4):
        rd=run/f'repeat_{n:02d}'
        if name=='C_sequential':
            scene=next(s for s in json.loads((rd/'SCENES.json').read_text()) if s['name']==name)
            a=[r['http_ms'] for r in records(rd/'runner/REQUESTS.jsonl') if r['scene']==scene['result']['runner_scene']]
        else:a=[r['total_ms'] for r in records(rd/name/'REQUESTS.jsonl')]
        assert len(a)==1000;pooled.extend(a);means.append(statistics.fmean(a))
    expected=d['aggregates'][name];assert math.isclose(statistics.fmean(means),expected['mean_of_repeat_means'],abs_tol=1e-8)
    assert math.isclose(statistics.stdev(means),expected['sample_sd'],abs_tol=1e-8)
    for p,key in [(.50,'p50'),(.95,'p95'),(.99,'p99')]:assert math.isclose(quantile(pooled,p),expected['pooled_complete_load_stats'][key],abs_tol=1e-8)
    checks.append({'scene':name,'actual_repeats':4,'n':len(pooled),'mean_sd_p50_p95_p99_recomputed':True})
for n in range(4):totals.update(str(r['status']) for r in records(run/f'repeat_{n:02d}/runner/REQUESTS.jsonl'))
assert dict(totals)==d['all_http_status_counts'];assert sum(totals.values())==69036
assert len(list(csv.DictReader((OUT/'SCENE_RESULTS.csv').open())))==57
old=json.loads((ROOT/'output/week7_power_abort/20261028T213602Z/HISTORY_BEFORE.json').read_text())['files']
changed=[k for k,h in old.items() if not (ROOT/k).is_file() or sha(ROOT/k)!=h]
assert not changed,changed
stages=[]
for s in d['scenes']:
    for stage,metrics in s['stages'].items():
        if metrics:stages.append(dict(repeat=s['repeat'],scene=s['scene'],boundary=s['boundary'],cache=s['cache'],stage=stage,success_only=s['boundary']=='C',**metrics))
with (OUT/'STAGE_RESULTS.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(stages[0]));w.writeheader();w.writerows(stages)
result={'passed':True,'standard_library_crosscheck':checks,'all_status_request_accounting':dict(totals),'historical_files_unchanged':len(old),'full_five_repeat_certification':False,'no_fifth_repeat_imputation':True}
(OUT/'TABLE_CROSSCHECK.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
