"""Descriptive audit of observed scenes. Never certifies a missing fifth repeat."""
from pathlib import Path
from collections import Counter
import csv, hashlib, json, sys
import numpy as np

ROOT=Path('/Users/zhangjunhao/Desktop/MMPSR')
sys.path.insert(0,str(ROOT))
RUN=ROOT/'output/week7_formal_v2/attempt_20261028T234359Z'
OUT=Path(__file__).resolve().parent
def read(p): return json.loads(Path(p).read_text())
def records(p):
    if not Path(p).exists(): return
    with Path(p).open() as f:
        for line in f:
            if line.strip(): yield json.loads(line)
def sha(p):
    with Path(p).open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def save(name,x): (OUT/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def stats(xs):
    if not xs:return None
    a=np.asarray(xs,dtype=np.float64); assert np.isfinite(a).all() and (a>=0).all()
    return dict(n=len(a),mean=float(a.mean()),p50=float(np.quantile(a,.50)),p95=float(np.quantile(a,.95)),p99=float(np.quantile(a,.99)),max=float(a.max()),under200=float((a<200).mean()))
def crosscheck(a,b):
    assert a['n']==b['n']
    for k in ['mean','p50','p95','p99','max']: assert np.isclose(a[k],b[k],rtol=1e-12,atol=1e-9),(k,a[k],b[k])
def csvfile(name,items):
    if not items:return
    cols=list(dict.fromkeys(k for x in items for k in x))
    with (OUT/name).open('w') as f:
        w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows(items)

registration=read(RUN/'REGISTRATION.json'); refs=read(RUN/'REFERENCE_SIGNATURES.json')['signatures']
asset_checks={k:sha(v['path'])==v['sha256'] for k,v in registration['asset_manifest'].items()}
code_checks={k:sha(ROOT/k)==v for k,v in read(RUN/'CODE_LOCK.json').items()}
assert all(asset_checks.values()) and all(code_checks.values())
old=ROOT/'output/week7_performance_revalidation/local_cpu_/20261027T162701Z'
historical=read(RUN/'HISTORY_BEFORE.json'); history_checks={k:(old/k).is_file() and sha(old/k)==h for k,h in historical.items()}
assert all(history_checks.values())
all_scenes=[]; round_audits=[]; warm=[]; blocks=[]; resources=[]; start_info=[]; samples={}; paired=[]
for rd in sorted(RUN.glob('repeat_[0-9][0-9]')):
    n=int(rd.name[-2:])+1; reg=read(rd/'REGISTRATION.json'); startup=read(rd/'REAL_STARTUP.json')
    assert reg['hardware_fingerprint']==registration['hardware_fingerprint']
    assert startup['hardware']==registration['hardware']
    assert startup['core_instances']==1 and startup['catalog_count']==startup['index_ntotal']==164900
    assert read(rd/'online_equivalence100/SUMMARY.json')['passed']
    core=read(rd/'core_equivalence20/EQUIVALENCE.json');assert core['passed']
    start_info.append(dict(repeat=n,nonce=reg['nonce'],epoch=reg['process_epoch'],api_pid=startup['service_identity']['pid'],encoder_pid=startup['encoder_identity']['pid']))
    starts=list(records(rd/'runner/STARTS.jsonl')); rows=list(records(rd/'runner/REQUESTS.jsonl'))
    byid={r['trace_id']:r for r in rows}; assert len(byid)==len(rows)
    ids={r['trace_id'] for r in starts};assert ids==set(byid)
    completion=list(records(rd/'SERVER_COMPLETION.jsonl')); life=list(records(rd/'ASGI_LIFECYCLE.jsonl'))
    assert ids=={r['trace_id'] for r in completion}=={r['trace_id'] for r in life if r['event']=='start'}=={r['trace_id'] for r in life if r['event']=='complete'}
    assert all(r['instance']==reg['nonce'] for r in completion+life)
    bodies=0; exact_successes=0
    for b in records(rd/'HTTP_BODIES.jsonl'):
        r=byid[b['trace_id']];bodies+=1;assert b['http_status']==r['status']
        assert np.isclose(r['http_ms'],(b['received']-r['send'])*1000,rtol=0,atol=1e-9)
        if r['status']==200:
            sig=[[p['product_locale'],p['product_id'],p['rank'],p['score']] for p in b['body']['results']]
            assert sig==refs[r['query_id']][:10] and r['same_prediction'] is True;exact_successes+=1
    assert bodies==len(rows)
    from project.esci_sqid.week7_formal_v2.contract import verify_leases,check_condition
    verify_leases(list(records(rd/'LEASE_EVENTS.jsonl')),list(records(rd/'DRAIN_EVENTS.jsonl')),ids)
    final=read(rd/'FINALIZATION.json');assert final['drain_confirmed'] and final['unfinished']==0 and final['request_id_sets_match']
    assert final['issued']==final['terminal']==len(rows)
    scenes=read(rd/'SCENES.json');per_round=[]
    for scene in scenes:
        if 'end' not in scene:continue
        name=scene['name'];v=scene['result'];kind=scene['kind'];complete=bool(v.get('complete'))
        common=dict(repeat=n,scene=name,kind=kind,workload=scene['workload'],cache=scene['cache'],load_complete=complete)
        if scene['cache']=='two_pass':
            c=read(rd/f'CONDITION_{name}.json');count=scene.get('count',len(reg['ordered_workloads'][scene['workload']]))
            check_condition(c['passes'],count);assert not any(c['empty'][k] for k in ['hits','misses','currsize'])
            for p in c['passes']:
                warm.append(dict(repeat=n,scene=name,pass_number=p['pass'],queries=p['queries'],seconds=p['seconds'],hits=p['hits'],misses=p['misses'],hit_rate=p['hits']/(p['hits']+p['misses'])))
        if kind in ['paired','cached','online']:
            rr=list(records(rd/name/'REQUESTS.jsonl'));ss=list(records(rd/name/'STARTS.jsonl'))
            assert len(rr)==len(ss)==scene['count'] and all(r['status']=='ok' for r in rr)
            assert [r['query_id'] for r in rr]==[q['query_id'] for q in reg['ordered_workloads'][scene['workload']][:scene['count']]]
            if kind=='online':assert all(r['signature']==refs[r['query_id']][:10] for r in rr)
            if kind=='cached':
                cr=read(rd/'CACHED_REFERENCES.json')['signatures'];assert all(r['signature']==cr[r['query_id']] for r in rr)
            x=[r['total_ms'] for r in rr]
            detail={**common,'boundary':'B' if kind=='online' else 'A','stats':stats(x),'statuses':{'ok':len(rr)},'stages':{k:stats([r['timings_ms'][k] for r in rr if r['timings_ms'].get(k) is not None]) for k in set().union(*(r['timings_ms'] for r in rr))}}
        else:
            rr=[r for r in rows if r['scene']==v['runner_scene']];assert len(rr)==v['requests']
            x=[r['http_ms'] for r in rr];actual=stats(x);crosscheck(actual,v['all_http_ms'])
            status=dict(Counter(str(r['status']) for r in rr));assert status==v['status_counts']
            ok=[r for r in rr if r['status']==200];span=v['drained']-v['start'];offered=v['stop_sending']-v['start']
            detail={**common,'boundary':'C','stats':actual,'statuses':status,'success_fraction':len(ok)/len(rr),'coalesced':sum(bool(r.get('coalesced')) for r in rr),'error_codes':dict(Counter(r.get('error',{}).get('code') for r in rr if isinstance(r.get('error'),dict))),'successful_stats':stats([r['http_ms'] for r in ok]),'queue_wait':stats([r['timings_ms']['queue_wait'] for r in ok if 'queue_wait' in r.get('timings_ms',{})]),'issue_window_s':offered,'last_send_offset_s':max(r['send'] for r in rr)-v['start'],'drain_s':v['drained']-v['stop_sending'],'total_span_s':span,'success_effective_rps':len(ok)/span,'all_status_effective_rps':len(rr)/span,'coalesced_successes':sum(bool(r.get('coalesced')) for r in ok),'noncoalesced_successes':sum(not r.get('coalesced') for r in ok),'load_supply_exhausted':v.get('load_supply_exhausted',False),'stages':{k:stats([r['timings_ms'][k] for r in ok if r.get('timings_ms',{}).get(k) is not None]) for k in set().union(*(r.get('timings_ms',{}) for r in ok))}}
            if kind=='closed_loop':
                for client in range(scene['clients']):
                    cr=sorted([r for r in rr if r['client_id']==client],key=lambda z:z['send']);assert all(y['send']>=z['received'] for z,y in zip(cr,cr[1:]))
                if complete:assert abs(offered-scene['seconds'])<1e-6
                for offset in range(0,int(scene['seconds']),30):
                    lo=v['start']+offset;hi=lo+30;sent=[r for r in rr if lo<=r['send']<hi];ended=[r for r in rr if lo<=r['received']<hi]
                    blocks.append(dict(repeat=n,scene=name,offset_s=offset,started=len(sent),completed=len(ended),successes=sum(r['status']==200 for r in ended),errors=sum(r['status']!=200 for r in ended),coalesced=sum(bool(r.get('coalesced')) for r in ended),success_rps=sum(r['status']==200 for r in ended)/30,statuses=json.dumps(dict(Counter(str(r['status']) for r in ended))),offered_seconds=max(0,min(30,offered-offset))))
            if kind=='burst':
                assert len(v['waves'])==scene['waves'] and len(rr)==scene['clients']*scene['waves']
                for wave in range(scene['waves']):
                    wr=[r for r in rr if r['wave']==wave];assert len(wr)==scene['clients'] and len({r['query'] for r in wr})==scene['clients']
        all_scenes.append(detail);per_round.append(detail);samples.setdefault(name,[]).append((n,x,complete))
    from project.esci_sqid.week7_performance_revalidation.core_runner import restore_array_record
    from project.esci_sqid.week7_performance_revalidation.records import assert_exact_core
    ar=list(records(rd/'paired_A0/REQUESTS.jsonl'));br=list(records(rd/'paired_A2/REQUESTS.jsonl'));a={r['query_id']:r for r in ar};b={r['query_id']:r for r in br};assert a.keys()==b.keys() and len(a)==200
    for q in a:
        assert_exact_core(restore_array_record(rd/f'paired_A0/query_{q}.npz'),restore_array_record(rd/f'paired_A2/query_{q}.npz'))
    paired.append(dict(repeat=n,queries=200,exact=True,paired_A0_minus_A2_ms=stats([a[q]['total_ms']-b[q]['total_ms'] for q in a]),mean_A0_ms=float(np.mean([r['total_ms'] for r in ar])),mean_A2_ms=float(np.mean([r['total_ms'] for r in br]))))
    for f in ['RESOURCES.jsonl','WORKER_RESOURCES.jsonl']:
        peak={};start_t=None;end_t=None;cpu_start={};cpu_end={};swap_peak=0
        for r in records(rd/f):
            t=r.get('t');start_t=t if start_t is None else start_t;end_t=t
            for p in r.get('processes',[]):
                role=p.get('role','unknown');peak[role]=max(peak.get(role,0),p.get('rss_bytes',0));cpu=p.get('cpu_times',{});cpu_start.setdefault(role,cpu);cpu_end[role]=cpu
            if r.get('controller'):peak['controller']=max(peak.get('controller',0),r['controller'].get('rss_bytes',0))
        resources.append(dict(repeat=n,source=f,peak_rss_bytes=peak,observed_seconds=(end_t-start_t) if end_t and start_t else None,cpu_seconds_start=cpu_start,cpu_seconds_end=cpu_end))
    round_audits.append(dict(repeat=n,executed_scenes=len(per_round),complete_load_scenes=sum(s['load_complete'] for s in per_round),http_issued=len(starts),http_terminal=len(rows),status_counts=dict(Counter(str(r['status']) for r in rows)),prediction_successes_verified=exact_successes,asgi_lease_ack_idle_verified=True,finalization=final,canonical_round_completion_exists=(rd/'COMPLETION.json').exists(),canonical_cleanup_exists=(rd/'CLEANUP_PROOF.json').exists()))
    print('Audited repeat',n,'scenes',len(per_round),'HTTP',len(rows),flush=True)

aggregate={};rng=np.random.default_rng(20261029)
for name,rs in samples.items():
    complete=[r for r in rs if r[2]];means=np.asarray([np.mean(r[1]) for r in complete]);pooled=[v for r in complete for v in r[1]]
    ci=np.quantile(means[rng.integers(len(means),size=(5000,len(means)))].mean(axis=1),[.025,.975]).tolist() if len(means)>1 else None
    aggregate[name]={'complete_repeat_ids':[r[0] for r in complete],'incomplete_repeat_ids':[r[0] for r in rs if not r[2]],'number_of_complete_repeats':len(complete),'round_means':means.tolist(),'mean_of_repeat_means':float(means.mean()) if len(means) else None,'sample_sd':float(means.std(ddof=1)) if len(means)>1 else None,'repeat_bootstrap95':ci,'pooled_complete_load_stats':stats(pooled),'worst_complete_round_mean':float(means.max()) if len(means) else None,'actual_observed_scenes':len(rs),'not_preregistered_five_repeat_certification':True}
guard=ROOT/'output/week7_power_abort/guard_20261028T234355Z';clock_counts=Counter();clock_max_gap=0;checks=0
for row in records(guard/'CLOCK_POWER_SAMPLES.jsonl'):
    c=row.get('comparison',{});checks+=1;clock_max_gap=max(clock_max_gap,abs(c.get('sleep_gap_ns',0)))
    for k in ['sleep_detected','wall_adjustment_detected','clock_rate_or_sampling_fault']:
        if c.get(k):clock_counts[k]+=1
assert not clock_counts['sleep_detected'] and not clock_counts['clock_rate_or_sampling_fault']
assert len({i['nonce'] for i in start_info})==len(start_info)==4
supplement=read(ROOT/'output/week7_power_abort/formal_launch_20261028T234347Z/SUPPLEMENTAL_CLEANUP.json')[-1]
assert supplement['event']=='post_shutdown_observation' and not supplement['alive']
assert supplement['shutdown']['original_lifespan_returned'] and supplement['shutdown']['encoder_returncode'] in [0,-15]
assert all(supplement['shutdown']['dispatcher'][k]==0 for k in ['active_jobs','pending_jobs','waiters'])
assert supplement['shutdown']['nonce']==start_info[-1]['nonce']
assert all((RUN/f'repeat_{i:02d}/CLEANUP_PROOF.json').exists() for i in range(3))
summary={'source_attempt':str(RUN),'planned_repeats':5,'started_repeats':4,'completed_scene_grid_repeats':[1,2,3],'partial_repeat':4,'fifth_repeat_not_started':True,'preregistered_five_repeat_certified':False,'descriptive_completed_scene_audit_passed':True,'asset_checks':asset_checks,'code_checks':code_checks,'historical_files_unchanged':len(history_checks),'identities':start_info,'rounds':round_audits,'scenes':all_scenes,'aggregates':aggregate,'paired_exactness':paired,'resources':resources,'clock_observations':{'samples':checks,'detected_events':dict(clock_counts),'max_absolute_continuous_minus_perf_gap_ns':clock_max_gap,'recording_stopped_on_observer_failure':True,'guard_final_record_missing':True},'stop_reason':read(guard/'ABORT_REQUESTS.json'),'all_http_status_counts':dict(sum((Counter(r['status_counts']) for r in round_audits),Counter())),'relevance_labels_read':False,'independent_compute_throughput':'not identifiable from HTTP/ASGI alone','missing_canonical_files_not_backfilled':True,'bootstrap_unit':'repeat; descriptive intervals use actual available repeats, not the preregistered five-repeat certification','incomplete_load_scenes_retained_individually':True}
save('DESCRIPTIVE_RECOMPUTATION.json',summary)
csvfile('SCENE_RESULTS.csv',[{**{k:v for k,v in s.items() if k not in ['stats','stages','successful_stats','queue_wait']},**{('latency_'+k):v for k,v in s['stats'].items()}} for s in all_scenes])
csvfile('CACHE_WARMUP.csv',warm);csvfile('SUSTAINED_30S_BLOCKS.csv',blocks)
save('RAW_AUDIT_RESULT.json',{'passed':True,'scope':'completed-scene descriptive analysis only','assets_verified':len(asset_checks),'code_files_verified':len(code_checks),'historical_files_unchanged':len(history_checks),'http_requests':sum(r['http_terminal'] for r in round_audits),'exact_paired_query_checks':800,'full_five_repeat_certified':False,'all_started_epochs_closed':True,'supplemental_shutdown_record':str(ROOT/'output/week7_power_abort/formal_launch_20261028T234347Z/SUPPLEMENTAL_CLEANUP.json')})
print(json.dumps({'audit_passed':True,'http_requests':sum(r['http_terminal'] for r in round_audits),'scene_observations':len(all_scenes),'planned_five_repeat_certified':False,'output':str(OUT)},indent=2))
