# Results, discussion, limitations and conclusion: evidence review

Reviewed 2026-10-25 against the approved `output/final_report_evidence_audit_20261025/EVIDENCE_MATRIX.json`, approved outline, saved engineering aggregate recomputations, and the already reviewed frozen error-case record. No report prose or tables were edited. No raw qrels, new model predictions, model execution, tuning, or metric reruns were used.

## Concrete changes

### 1. State the missing Week4 index/latency gate outcome in Results

**Location:** `sections/05_results.tex:22` (after the 14.35% raw-Fusion result); optionally an extra row or short panel near `tables/final_targets.tex`.

The main target accounting currently covers only the three NDCG targets. The approved original-requirement evidence also includes the Week4 catalog-size and retrieval-latency gates. Add one compact statement: the 164,900-product index passes the 100,000-product requirement; the original final-run cached Fusion FAISS mean is 65.2408 ms and P95 is 69.1430 ms, so the <50 ms retrieval gate is unmet. Keep this final-run CPU/cache boundary distinct from later optimized-core timing. Also identify the +14.35% result as meeting the +10% **known-positive proxy** gate, preserving the present statement that it is not fully judged true recall. This avoids leaving the original latency target unaccounted for while reporting the later 21.97x engineering speedup.

**Evidence:** `ESCI-TARGET-W4-001`, `ESCI-TARGET-W4-002`; frozen `evaluation/original_project_requirements.json` and final `latency/summary.json` locators recorded in those audit rows.

### 2. Exempt the projection row from the generic OOF and 0.002-gate table note

**Location:** `tables/optimization_summary.tex:30` (note below the table; source generator `tables/build_tables.py`).

The note says P1 is internal 80/20 and “other ranking rows use three grouped out-of-fold comparisons,” then gives a general promotion rule including an absolute 0.002 gain. The final row is projection heads evaluated on **external Cold-Val**, not OOF, and its saved selection rule is Cold-Val pool NDCG improvement with no Warm decrease. The body and Results describe that row correctly, so the generic note contradicts them.

Scope the OOF/.002 note to the P2 and targeted ranking studies, and add a separate clause that projection uses its saved Cold-improves/Warm-nondegradation rule. No numeric cells need changing.

**Evidence:** `ESCI-W6-002/003`, `OPT-W6-RANK`, `OPT-P2A-*`, `OPT-TARGET-*`; `tables/adaptation.tex` already gives the correct projection protocol.

### 3. Bound the “only retrieval direction” claim to the controlled follow-ups

**Location:** `sections/05_results.tex:66`.

“The only retrieval direction with recurring positive evidence is RRF60” is overly broad immediately after Results has demonstrated repeated calibrated-Fusion gains. Change its subject to “Among these controlled follow-up directions, RRF60 has recurring positive recall evidence ...”. Its non-adoption and Cold-Val uncertainty remain correctly stated.

**Evidence:** `ESCI-CAL-002`, `ESCI-TARGET-W4-001`, `OPT-P2C-*`, `OPT-TARGET-D`, `ESCI-FINAL-RRF-001`.

### 4. Name the actual historical Week6 system and qualify historical Recall@50

**Locations:** `sections/05_results.tex:75`; notes in `tables/historical_controls.tex`.

Replace “the multimodal combination with content-gated compensation” with “the expanded pretrained text-reranker ensemble with content-gated compensation.” The saved 200-query system combines BGE, Qwen3-Reranker-4B, an adapted-vector signal and a Qwen3.5 signal; it is not the simple vector-plus-small-LLM system or the Week5 supervised residual. The existing 14.02%, 95 eligible queries, and separate-panel boundary are correct.

Add to the historical table note that historical Recall@50 counts known silver grade>=2 positives in the common judged candidate pool, and is not exhaustive catalog relevance. Current notes correctly identify synthetic queries and silver labels but leave this recall denominator implicit.

**Evidence:** `META-08`, `META-23/24`; their protocol/caveat fields explicitly require these distinctions.

### 5. Label the human review as full-text and grade-stratified in the Results sentence

**Location:** `sections/05_results.tex:81`.

Use “full-text” in place of “full-content” and identify the 100-pair sample as grade-stratified (25 pairs per model grade). The exact and binary rates are correct **unweighted sample agreement**, rather than population accuracy. The appendix table already notes the reused stratified sample, visible prior title scores and assisted review history; adding the sampling qualifier in the main sentence prevents the raw 50.51%/70.71% rates from sounding population-representative. Preserve the existing warning that this is not an independent complete human-judged ranking pool.

**Evidence:** `META-26/27`; `tables/historical_human_review.tex` notes.

### 6. Make the HTTP latency denominator explicit for the overload row

**Location:** notes in `tables/online_http.tex:30`.

Add “Latency summaries use successful responses.” The 96-request overload row reports 68/96 successes, but its mean/P95/max summarize the 68 successful requests, not all 96 including immediate HTTP 429 rejections. This is a table-label precision issue; the recorded values and prose counts are correct.

**Evidence:** `ENG-16`; `output/final_report_evidence_audit_20261025/week7/queue64_recomputed.json`, `/runs/0/phases/burst_96/http_ms` has count 68 and the displayed 3201.424 ms mean.

## Checks that require no change

- Final Warm, Cold-Test and Overall fixed-pool point estimates, query counts, paired intervals and NDCG target outcomes match the approved audit. ListNet is not substituted for the named LambdaMART gate. The ListNet–LambdaMART interval crossing zero and the uncertain Cold improvement are accurately described.
- Raw Fusion versus raw SBERT is separated from A/B reranked flows. All shown catalog means, the 14.35% relative gain, and the +0.0230 Cold B-minus-A difference match the saved aggregates. RRF remains auxiliary despite favorable Final Test evidence; no recall-to-NDCG substitution is made.
- The image ablation is development-only, removes image-dependent score processing with image features, and is not claimed as an isolated causal pixel effect. Image-subgroup eligible populations are not summed or treated as independent.
- Projection alignment, Warm/Cold-Val ranking and catalog recall changes match the audit. Its failed selection, frozen ranker, absent factorial cause isolation and non-adoption are preserved.
- P1/P2/targeted effect sizes, signs, confidence intervals, 18,758-product pseudo-Cold holdout and unpromoted decisions match the audit. Small positive P2A intervals are not equated with passing the 0.002 practical gate.
- The five main-text archived error illustrations preserve the reported movements and label ambiguity. They do not assign new labels, infer prevalence, or claim that saved top ten explains all Cold Recall@50 changes. The appendix explicitly notes that displayed labels are not target-scope membership tags.
- Historical 19.00%, 24.01%, 10.55% and 14.02% values and matched image-off/strong-text/CE-only controls are accurate. The unresolved earlier 48K +21.15% package is not substituted for verified later evidence. The human-review percentages reproduce 50/99 and 70/99.
- Same-session A0/A1/A2 timing, 300 correlated repeats over 100 queries, exactness scope and 21.974x mean ratio are correctly bounded. Engineering hardware allocation is not presented as GPU execution of the CPU core or live service.
- The live-encoder compatibility counts 100/100 Top100 sets, 95/100 candidate orders, 100/100 final Top10 orders, 100/100 Top50 sets and 97/100 full ranks match the saved gate. Both minimum vector cosines exceed 0.999999999999 as stated. Historical SQID bitwise identity remains unresolved.
- New-query HTTP, warmed 96-query reference, finite repeated 64-query load, overload/recovery counts, configured limits, startup and summed RSS match the saved summaries. The draft distinguishes one compute slot, bounded queuing, loopback HTTP, excluded images/browser rendering, and unproven production readiness. Earlier failures are preserved.
- Discussion, limitations and conclusion introduce no new quantitative result, stable-superiority claim, successful Cold adapter, production-scale service claim, or retrospective model adoption.
- Visible main table references consistently match the recommended table labels. Main Results refers to `app:subgroups`, whose technical appendix is being authored in parallel; no broken-reference conclusion is drawn before integration.

## Reviewed snapshot identities

These hashes identify the read-only review snapshot; parallel authoring may update files afterward.

```json
{
  "sections/05_results.tex": "8e49384f03839975f12b8467f9e914af9d34488328646b0900c5b85e5ecbab7c",
  "sections/06_discussion.tex": "a5b288c43e889491b3e6f68793be3b4021c120f3dbd118d0f7fbf2789fba4e52",
  "sections/07_limitations.tex": "845cde9c91b5165bd65128ecbccbdc36b7078609bcca7225539538ce43228dda",
  "sections/08_conclusion.tex": "91ff0685ff999e31189304188c63a8cc169f8a1a144639182c79bfe61234810f",
  "tables/final_judged_pool.tex": "dce3c3726214b931fd2b3e1c7546e29824de583b1238989492e1c3cc35263775",
  "tables/final_targets.tex": "89307d41d77f54ae0f5ef72fe3148bc8e86eb6c50390b3321a7a1a3506c6f10f",
  "tables/final_catalog.tex": "9fbd89e80716cf2792c492f73aa15cdc4ba5f279bda231d0cad00332f0c212ef",
  "tables/development_retrieval.tex": "57e78d7ea010bedda48d5ebbe031b68257ce9ea8089b43b5b695a79b91294dcb",
  "tables/validation_ablations.tex": "5363581eb8e3f18eb696faa1db22e1559bde8b3566b6755400129a85832ef7eb",
  "tables/adaptation.tex": "2aa85608a80cc66cb02f795974149e46dba1183de544b035d33872df8ea09c1c",
  "tables/optimization_summary.tex": "94e87b5d9cb9888f7c77ba7d3622072af4b7b8cf4c7e4267aced35548c8eb16f",
  "tables/rrf_chronology.tex": "4ea67fb4da6c56e1985a6c367441c8e1b3b9a0a3fb5d75cdbbdfd1bb5de463b4",
  "tables/historical_controls.tex": "de95af9d3ea1d0ea547833585739446fda6e54afd392ef9bcf42890116e34976",
  "tables/historical_human_review.tex": "86f9882261887afc029c4d1f24fe9f33342fcebc83f7e0fb41704deb3c6d0158",
  "tables/core_timing.tex": "699c06f031b4b0e1a2d4afd6c290553602c586d4f720b289cd4d6588775af655",
  "tables/online_http.tex": "dc9fa28299d0719166e40cad8b89819fa4d267e5afc3bea57b50d8a9f21427d5"
}
```
