# Archived error-case analysis

Source: `project/esci_sqid/outputs/final_test/review/2026-10-17_283a65ed6bb4/approved_final_v1/evaluation/error_cases.json` (SHA-256 `580077efdaad2b995e350673486feedd8981721905e04eb4643515e38cc9a6fb`). Evidence ID: ESCI-ERROR-001. Prepared 2026-10-25.

The existing selector supplies five improvements and five degradations for each of five fixed-pool contrasts, plus ten cases for the auxiliary catalog contrast. All 60 archived cases are indexed in `error_case_notes.json`; the appendix prints the ten cases for the main final ListNet-versus-original-Week2 Warm contrast. No test evaluation was rerun.

## Reading boundaries

- Only archived saved case rows, their already released labels, selector source, and the approved evidence matrix/outline were read. No raw qrels, new model predictions, training, tuning, or Final Test execution was used.
- The fixed-pool Week2, Week5, ListNet-vs-LambdaMART and ListNet-vs-Week2 examples use Warm target NDCG@10; Week6 examples use Cold-Test target NDCG@10. All competitors remain in their original positions.
- Catalog RRF_vs_Fusion_Cold compares reranked flows B minus A, not raw RRF versus raw Fusion. Its metric is Cold known-positive Recall@50, while the saved examples expose only top ten results.
- A displayed released E/S/C/I label is not a product-scope tag. Therefore the illustrated row movements are not a decomposition of the scoped query delta.
- These largest-delta cases are deliberately extreme. They are not a representative sample, cannot estimate category frequency, and do not establish causal mechanisms.
- Unexpected released labels are retained. Possible annotation ambiguity or information outside the shown titles is not resolved by this report.

Ranks retain complete competitor positions. Missing old/new rank means absent from that side of the saved top ten, not absent from its complete candidate set. Product target-scope membership is not present in the case record; no membership is inferred from an E/S/C/I label.

## Six draft main-text illustrations

### 23410 — Product type under a noisy entity query

For query 23410, “cartera de guchi”, ListNet moves the E-labeled Gucci bifold wallet B077YC45WB from outside the saved Week2 top ten to rank 1, while the I-labeled Gucci Bloom perfume B0757ZLMLZ moves from rank 1 to outside the saved ListNet top ten (Warm delta NDCG@10 = +0.8401). The titles support a product-type distinction under a noisy query; they do not demonstrate a learned spelling or translation step.

| Product ID | Released label | Old → new visible rank | Exact saved title |
|---|---|---|---|
| B0757ZLMLZ | I | 1 → >10 | Gucci Bloom for Women Eau de Parfum Spray, 3.3 Ounce, Multi |
| B077YC45WB | E | >10 → 1 | Gucci GG Original Canvas With Grained Leather Trim Bifold Wallet, Black |

### 63499 — Explicit negative attribute, with incomplete and unexpected judgments

For query 63499, “long overnight pads for women heavy flow without wings”, the E-labeled Always Maxi “without Wings” product B01IAI6SD6 rises from outside LambdaMART's saved top ten to ListNet rank 1 (Warm delta +0.3891). The previous first result B01N7HMX75 explicitly says “with Wings” but is unknown, and another with-wings product B000066SY1 is released as E. The visible movement is consistent with attending to a negative attribute, but the archive does not isolate that mechanism or resolve the label/title ambiguity.

| Product ID | Released label | Old → new visible rank | Exact saved title |
|---|---|---|---|
| B01IAI6SD6 | E | >10 → 1 | Always Maxi Pads Long Super without Wings 22 ea (Pack of 2) |
| B01N7HMX75 | unknown | 1 → 2 | U by Kotex Security Maxi Pads with Wings, Overnight, Unscented, 112 Count (4 Packs of 28) |
| B000066SY1 | E | 2 → 6 | U by Kotex Security Maxi Feminine Pads with Wings, Overnight Absorbency, Unscented, 14 Count |

### 70106 — Negation-sensitive degradation with contradictory title cues

For query 70106, “modern ceiling fan without light”, the I-labeled CHANFOK “fan with Light” B09BF1JJ9K rises from outside Week2's saved top ten to ListNet rank 1 (Warm delta -0.5197). Yet Week2's first product B07YBRPL4G also says “with Light” and is released as E, and a title explicitly saying “without Light Fixture” B01CDGCVBE leaves the saved top ten from rank 5. This is a judgment-relative regression involving a negated attribute, with released labels that preclude a simple title-only correctness claim.

| Product ID | Released label | Old → new visible rank | Exact saved title |
|---|---|---|---|
| B09BF1JJ9K | I | >10 → 1 | CHANFOK Ceiling fan with Light - Flush Mount Modern Indoor 19.7" LED Dimmable Low Profile Ceiling Fans with Remote Control,Smart 3 Light Color Change and 6 speeds (Black) |
| B07YBRPL4G | E | 1 → 4 | Westinghouse Lighting 7224200 Comet Indoor Ceiling Fan with Light, Matte Black |
| B01CDGCVBE | E | 5 → >10 | Hunter Fan Company 53294 Builder Elite Versatile Indoor/Outdoor 52 Inch Ceiling Fan without Light Fixture, Matte Black, 52" |

### 41911 — Negation and released-label ambiguity

For query 41911, “food freeze dryer machine not dehydrator”, the I-labeled Dehyber dehydrator B08JZ45W7W rises from Week2 rank 8 to ListNet rank 1 (Warm delta -0.3969). Week2's old first result B07SQMVLFH is also explicitly a “Food Dehydrator” but is released as E. The decline is valid against the frozen judgments; visible titles alone do not establish that one model respects the exclusion while the other fails it.

| Product ID | Released label | Old → new visible rank | Exact saved title |
|---|---|---|---|
| B08JZ45W7W | I | 8 → 1 | Dehyber Food dehydrator ,8-Tray Dehydrators for Food and Jerky with Digital Temperature Control and Timer,304 Stainless Steel food dryer dehydrator for Beef,Fruit,Dog Treats |
| B07SQMVLFH | E | 1 → >10 | Brod & Taylor SAHARA Folding Food Dehydrator, Beef Jerky, Fruit Leather, Vegetable Dryer (Stainless Steel Shelves) |

### 97509 — Primary product versus accessory in Cold-Test ranking

For query 97509, “stand mixer”, the C-labeled mixer cover B081JKZ9FC falls from Week2 rank 1 to outside ListNet's saved top ten; the E-labeled KitchenAid mixer B00005UP2P becomes first from outside Week2's saved top ten, and the E-labeled Cuisinart mixer B01H7R1EJY moves from rank 8 to 4 (Cold-Test delta +0.7736). This is consistent with preferring the appliance over some accessories. It is not a universal accessory-label rule: another dust cover, B088B62BV3, is released as E.

| Product ID | Released label | Old → new visible rank | Exact saved title |
|---|---|---|---|
| B081JKZ9FC | C | 1 → >10 | Powstro K Stand Mixer Cover Dust-proof with Organizer Bag for Kitchen aid Mixer |
| B00005UP2P | E | >10 → 1 | KitchenAid KSM150PSER Artisan Tilt-Head Stand Mixer with Pouring Shield, 5-Quart, Empire Red |
| B01H7R1EJY | E | 8 → 4 | Cuisinart SM-50 5.5 - Quart Stand Mixer, White |
| B088B62BV3 | E | 6 → >10 | Yarwo Visible Stand Mixer Dust Cover with Bottom for 6-8 qt Stand Mixer, Storage Case with Side Handle and Pockets, Gray |

### 105483 — Entity matching in the auxiliary catalog flow

For query 105483, “truly's”, auxiliary RRF-to-ListNet flow B places the E-labeled “Truly's Deodorant for Kids” B00JBCH312 first, outside formal Fusion-to-ListNet flow A's saved top ten; A's unknown first result “She's All I've Got Going” B073P4WJ6N becomes B rank 10 (Cold known-positive Recall@50 delta +1.0000). The titles show a visible entity-match shift, but the saved top ten cannot explain the complete Cold recall change; displayed labels do not identify target-scope membership, and unknown results remain unknown. The E-labeled Truly seltzer sign B08BTXJSLL also cautions against imposing a single product intent on this short query.

| Product ID | Released label | Old → new visible rank | Exact saved title |
|---|---|---|---|
| B00JBCH312 | E | >10 → 1 | Truly's Deodorant for Kids, Organic |
| B073P4WJ6N | unknown | 1 → 10 | She's All I've Got Going |
| B08BTXJSLL | E | >10 → 9 | Truly Spiked Hard Seltzer Tin Tacker Tin Sign - 23.5" x 8.25" |

## Catalog limitation worth stating

The A and B saved top ten are identical (including E-labeled B07XP6L7WP at rank 2 and B07JC2HV2W at rank 10), despite a Cold known-positive Recall@50 delta of -1. This is not an inconsistency that can be resolved from top ten records: the metric uses a Cold target mask and a larger cutoff.

Do not infer which Cold positives were lost, whether any displayed E belongs to Cold, or a retrieval mechanism from these top ten alone.

## Compact appendix coverage

The appendix retains the original five improved and five degraded ListNet-versus-Week2 selections in selector order, with exact query IDs/text, signed saved deltas, two product IDs/title excerpts per case, released labels and visible old/new positions. Full titles and additional archived rows remain in the JSON notes.

| Direction | Query ID | Query | Warm ΔNDCG@10 | Bounded observation |
|---|---|---|---:|---|
| Improved | 23410 | cartera de guchi | +0.8401 | ListNet moves wallet/bag titles ahead of Gucci perfume titles for the noisy query. This supports a visible product-type distinction; it does not establish a language-correction mechanism. |
| Improved | 73209 | newborn baby boy bunjee | +0.7162 | A doorway jumper rises while an infant boot remains second. The intended sense of bunjee cannot be established from the query alone; the saved E/I labels support the reported ranking contrast. |
| Improved | 100597 | tangent lost the | +0.7016 | Lost Then Found and Tangents rise relative to a title containing Loved and Lost. The query is too ambiguous to infer a precise intended entity from titles alone. |
| Improved | 29049 | cordless wall hanging fountains | +0.6782 | Fountain titles rise above decorative lights. The promoted fountain mentions an electric submersible pump, so this is not proof that cordless and wall hanging constraints are satisfied. |
| Improved | 26826 | cleveland big and tall | +0.6382 | Cleveland T-shirt titles rise above a baby bodysuit and other team merchandise. Big-and-tall sizing is not established by the displayed T-shirt titles. |
| Degraded | 70106 | modern ceiling fan without light | -0.5197 | ListNet puts two I-labeled with-light fans first. However, the old first result also says with Light and is released as E; simple title-based negation is not a complete explanation. |
| Degraded | 103771 | toddler sports bedding | -0.4262 | A Twin bedspread labeled I replaces the old first toddler set (E). A Full-size sports quilt is unknown, not I. The visible text supports a toddler-versus-larger-bed distinction, without isolating its cause. |
| Degraded | 59544 | ladder self closing for pool | -0.4109 | An I-labeled fence drill-guide product rises above an E-labeled pool entry system. This shows related equipment displacement; the self-closing attribute is not visible in the entry-system title. |
| Degraded | 41911 | food freeze dryer machine not dehydrator | -0.3969 | ListNet promotes I-labeled dehydrators for a not dehydrator query. The old top-ranked products also explicitly say dehydrator but are released as E; this is a measured judgment-relative decline, not an unambiguous semantic diagnosis. |
| Degraded | 65676 | mar'villa | -0.3936 | Two Mar'villa-titled products become first and second but have null saved labels, while an E-labeled Warrior Wand falls from first to third. Their null labels do not make them irrelevant; the visible text cannot establish that the new results are semantically worse. |
