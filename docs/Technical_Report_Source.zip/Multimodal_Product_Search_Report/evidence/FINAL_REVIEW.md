# Hard-case interpretation revision

The Discussion is expanded around annotation quality and Weeks 2, 3, 5 and 6. Each module is one connected paragraph. Observed behavior, plausible mechanisms and future proposals are separated in `HARD_CASE_ANALYSIS_EVIDENCE.json`. The saved case examples are grouped under a clearer hard-case heading, and the Conclusion briefly identifies the resulting research directions.

The discussion preserves the user's analysis while correcting unsupported causal or universal claims: human-label benchmark scores do not isolate annotation effects; 32B is a proposed annotator size rather than an established threshold; existing lexical features already contain partial constraint information; tested constraints/hard-negative weighting were not promoted; SFT and online RL are unimplemented proposals; current calibration is distinguished from the original score-scale problem; and missing-image Cold items are not uniformly worse across different eligible populations.

Two primary literature references support general discussion only. The LLM-judge paper concerns chatbot judging, while the feedback-trained rewriting paper concerns QA retrieval. Neither supplies a new product-search result. Their bibliographic metadata and scope are recorded in the reference ledger. The report now has 26 cited references.

The 35-page native build retains all 19 table fragments and their exact row values. Saved-source pointer checks, the original 28-feature order, titles/author metadata and the exact user-supplied architecture image are verified. No experimental assets, metrics, predictions, splits, models or labels are changed; no training, inference or evaluation is run. The prior 34-page delivery is archived.
