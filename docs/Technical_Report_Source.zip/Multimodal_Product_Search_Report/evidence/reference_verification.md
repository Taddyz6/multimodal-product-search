# Reference verification ledger

Verified on 25 October 2026. This ledger supports `references.bib`; papers establish method and dataset context, while the approved local audit establishes MMPSR behavior and outcomes. Only primary sources are used.

Bibliography contains **26 unique entries**. Required fields for the selected publication forms have been verified. Preprints and technical reports are cited explicitly instead of filling uncertain venue or pagination fields. No author affiliation, funding, acknowledgments, or submission status is inferred.

## Citation map and permitted context

| Key | Verified context | Project boundary | Primary source |
|---|---|---|---|
| `robertson2009bm25` | Probabilistic relevance framework review covering BM25 and BM25F. | Use as established sparse retrieval background; MMPSR tokenization and BM25 parameters require local code. | [Source](https://www.nowpublishers.com/article/DownloadEBook/INR-019) |
| `jarvelin2002cumulated` | Historical graded-gain evaluation reference. | The project metric formula, gains, masks, and eligible queries come from audited evaluation code. | [Source](https://researchportal.tuni.fi/en/publications/cumulated-gain-based-evaluation-of-ir-techniques/) |
| `reimers2019sentence` | Sentence-BERT uses siamese/triplet training to produce sentence embeddings comparable with cosine similarity. | SBERT is an established approach; cite the separate checkpoint card for MMPSR’s MiniLM implementation. | [Source](https://aclanthology.org/D19-1410/) |
| `radford2021clip` | CLIP jointly trains image/text encoders with symmetric cross-entropy on in-batch paired similarities. | Pretrained CLIP supplies representations; MMPSR does not introduce CLIP or its objective. | [Source](https://proceedings.mlr.press/v139/radford21a.html) |
| `reddy2022esci` | ESCI supplies manually judged Exact, Substitute, Complement, and Irrelevant query–product pairs. | Original paper gains are 1.0/0.1/0.01/0.0; MMPSR uses 7/3/1/0 and custom original-Test splits. | [Source](https://arxiv.org/abs/2206.06588) |
| `alghossein2024sqid` | SQID adds product images and CLIP product/query features to ESCI. | Its all-MiniLM-L12-v2 baseline differs from MMPSR’s L6-v2. Public CLIP model name does not prove historical extractor revision. | [Source](https://arxiv.org/abs/2405.15190) |
| `chen2016xgboost` | Scalable tree boosting system with sparsity-aware learning and weighted quantile sketch. | Cites implementation background; MMPSR’s pointwise regression objective/features are specified locally. | [Source](https://arxiv.org/abs/1603.02754) |
| `ke2017lightgbm` | LightGBM presents gradient-based one-side sampling and exclusive feature bundling for efficient boosted trees. | Library background is separate from the LambdaMART ranking formulation; do not claim every library technique was activated. | [Source](https://proceedings.neurips.cc/paper_files/paper/2017/hash/6449f44a102fde848669bdd9eb6b76fa-Abstract.html) |
| `cao2007listnet` | Top-one ListNet compares label and predicted softmax distributions using cross-entropy. | Distinguish original ListNet from MMPSR’s later gain-aware and position-aware evaluated variants. | [Source](https://www.microsoft.com/en-us/research/publication/learning-to-rank-from-pairwise-approach-to-listwise-approach/) |
| `burges2010lambda` | LambdaMART applies LambdaRank gradients in boosted regression trees. | MMPSR’s relevance gains, truncation, features, and selected training settings remain local implementation facts. | [Source](https://www.microsoft.com/en-us/research/publication/from-ranknet-to-lambdarank-to-lambdamart-an-overview/) |
| `johnson2017faiss` | GPU similarity-search implementation covering brute-force, approximate, and compressed-domain searches. | The 2017 preprint is cited consistently; its GPU focus is not evidence that MMPSR serving used a GPU. | [Source](https://arxiv.org/abs/1702.08734) |
| `cormack2009rrf` | RRF sums reciprocal shifted ranks; the original paper fixed k=60 after a pilot. | An established auxiliary fusion arm; report MMPSR route budgets and chronology from project evidence. | [Source](https://plg.uwaterloo.ca/~gvcormac/cormacksigir09-rrf.pdf) |
| `oord2018cpc` | InfoNCE classifies a positive among sampled alternatives with a normalized contrastive objective. | CPC provides loss context; MMPSR’s projection-only symmetric adaptation is not the CPC architecture. | [Source](https://arxiv.org/abs/1807.03748) |
| `hu2022lora` | LoRA freezes pretrained weights and learns low-rank weight updates. | Historical CLIP LoRA experiments only; final ESCI projection-only adaptation is distinct. | [Source](https://www.microsoft.com/en-us/research/publication/lora-low-rank-adaptation-of-large-language-models/) |
| `wang2020minilm` | MiniLM distills a teacher Transformer’s self-attention into a smaller student. | This architecture reference does not identify the sentence-embedding checkpoint or its subsequent training data. | [Source](https://proceedings.neurips.cc/paper/2020/hash/3f5ee243547dee91fbd053c1c4a845aa-Abstract.html) |
| `minilm_model` | Official card identifies a 384-dimensional sentence encoder and default 256-wordpiece truncation. | Project config and service code identify sentence-transformers/all-MiniLM-L6-v2; the card does not prove local frozen file hashes. | [Source](https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2) |
| `bge_model` | Official card identifies BAAI’s 768-dimensional English v1.5 embedding model. | Historical metadata pipeline only; audit META-10 records revision a5beb1e3e68b9ab74eb54cfd186867f64f240e1a. | [Source](https://huggingface.co/BAAI/bge-base-en-v1.5) |
| `bge_reranker_model` | Official cross-encoder card scores query–passage pairs directly. | Historical Week5 prior only; META-16 records revision 953dc6f6f85a1b2dbfca4c34a2796e7dde08d41e. | [Source](https://huggingface.co/BAAI/bge-reranker-v2-m3) |
| `qwen_model` | Official Qwen3.5-2B checkpoint card. | Historical query-only rewriting and text-only silver judging; META-07/08 record revision 15852e8c16360a2fea060d615a32b45270f8a8fc. | [Source](https://huggingface.co/Qwen/Qwen3.5-2B) |
| `qwen25_model` | Official Qwen2.5 instruction-tuned checkpoint card. | Historical initial Week6 scoring branch, rejected; not part of the formal ESCI system. | [Source](https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct) |
| `qwen_reranker_model` | Official Qwen3 4B text-reranking checkpoint card. | Historical Week6 ensemble; META-23 records revision 22e683669bc0f0bd69640a1354a6d0aebcfeede5. | [Source](https://huggingface.co/Qwen/Qwen3-Reranker-4B) |
| `faiss_indexes` | IndexFlatIP is exhaustive exact inner-product search; cosine search requires normalized input vectors. | Use this source for index semantics, and local code for the chosen index, device, and tie handling. | [Source](https://github.com/facebookresearch/faiss/wiki/Faiss-indexes) |
| `fastapi_docs` | Official Python API framework documentation. | Technology attribution only; no library marketing claim establishes MMPSR throughput or production readiness. | [Source](https://fastapi.tiangolo.com/) |
| `streamlit_docs` | Official Python data-application framework documentation. | Technology attribution only; UI functionality and HTTP measurements require project evidence. | [Source](https://docs.streamlit.io/) |

## Metadata choices

- BM25: Stephen Robertson and Hugo Zaragoza; 2009; *Foundations and Trends in Information Retrieval* 3(4):333–389; DOI 10.1561/1500000019. The publisher’s indexed PDF front matter verifies these fields.
- NDCG: Kalervo Järvelin and Jaana Kekäläinen; 2002; *ACM Transactions on Information Systems* 20(4):422–446; DOI 10.1145/582415.582418. The authors’ Tampere University publication record includes matching BibTeX.
- ListNet is cited as the verified Microsoft technical report MSR-TR-2007-40. LambdaMART is cited as MSR-TR-2010-82. The latter PDF gives the full author name Christopher J. C. Burges.
- FAISS is consistently the verified 2017 arXiv preprint, not a mixture of preprint and later journal metadata. XGBoost is the verified 2016 arXiv preprint. CPC uses its first-preprint year, 2018; its current v2 is dated January 2019.
- LoRA uses its verified ICLR 2022 publication year; the 2021 arXiv submission is not labeled a 2022 preprint.
- Model cards identify the exact model names recorded by project evidence. Generic current card content does not prove the frozen checkpoint revision. Model-card/documentation entries record access dates and use n.d. for unverified publication years.

## Access limitations and unresolved provenance

- **REF-ACCESS-BM25** (access_limitation_not_metadata_blocker): Direct publisher landing page and DownloadEBook return HTTP 403. Primary-domain indexed PDF front matter verifies the final bibliographic fields. No detailed BM25 formula was transcribed from an inaccessible page.
- **REF-ACCESS-NDCG** (access_limitation_not_metadata_blocker): ACM full text returns HTTP 403. Authors’ institutional record verifies authors, year, journal, volume, issue, pages, and DOI. This ledger does not assert original-paper formula details from that record.
- **REF-ACCESS-LORA** (access_limitation_not_metadata_blocker): OpenReview HTML browser challenge; venue/year verified independently in author institution’s primary publication record and indexed official PDF.
- **REF-HISTORICAL-IDENTITY** (project_provenance_limitation): Current model cards verify upstream artifacts, not exact historical file identity. Exact historical SQID extractor revision remains unresolved in the approved audit; retain this limitation.
- **REF-MODEL-DATES** (intentional_omission): Model-card and documentation entries use n.d. (undated) when no stable card publication date was verified. Each records the access date; research-paper years are explicit.

## Citation boundaries that matter for this report

- The original ESCI paper’s relevance gains differ from this report’s custom gains. Its official task scores cannot be compared directly to the custom MMPSR split/metric.
- SQID’s sentence-transformer baseline uses MiniLM-L12-v2; MMPSR’s configuration uses MiniLM-L6-v2. Cite the model card in addition to SBERT/MiniLM research context.
- Historical BGE/Qwen/LoRA components belong to the metadata/silver protocol. They are not dependencies of the formal frozen ESCI+SQID retrieval/ranking system.
- InfoNCE, top-one ListNet, LambdaMART, CLIP, BM25, and RRF are established methods. Project contributions concern construction, calibration, evaluation, and engineering choices, rather than invention of those methods.
- Faiss’s GPU paper does not establish the device used by the project. The exact IndexFlatIP semantics are independently documented by the official Faiss wiki.

Validation: local BibTeX with `plainnat` and all entries cited produced 24 bibliography items, exit code 0, with no warnings. Citation keys and the JSON ledger match.

## Hard-case discussion update, 26 October 2026

- `zheng2023judging`: [primary preprint](https://arxiv.org/abs/2306.05685). Supports the need to validate LLM-judge behavior against human judgments; does not establish any product-label accuracy or model-size threshold.
- `ma2023query`: [primary EMNLP paper](https://aclanthology.org/2023.emnlp-main.322/). Supports feedback-trained rewriting as prior methodology in QA retrieval; does not establish improvement from product-search SFT or online RL in this project.

These additions support Discussion/Future Work only. The original numerical results and experiment sources remain unchanged.
