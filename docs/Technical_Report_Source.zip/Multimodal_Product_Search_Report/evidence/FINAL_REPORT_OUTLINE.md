# MMPSR Final Technical Report — Evidence-Based Outline

**Stage:** Outline complete; full report prose, abstract, LaTeX and bibliography are not drafted.

**Working title:** *MMPSR: Multimodal Product Retrieval and Ranking with Human-Judged Evaluation and Efficient Serving*

The historical project name includes “LLM-Enhanced Query Understanding.” The final ESCI+SQID system does not use a validated LLM rewrite module. Keep the original name as project context rather than imply that this component is part of the final method. Use a NeurIPS-style research structure and technical presentation, without presenting the document as a NeurIPS submission. Length should follow the evidence rather than concatenate weekly reports or fill a page quota.

## 1. Claims the report can make

| Contribution / finding | Evidence IDs | Wording boundary |
|---|---|---|
| An aligned, reproducible human-judged product-search benchmark with frozen query/product roles and explicit evaluation boundaries. | ESCI-DATA-001–010; ESCI-METRIC-001–003; ESCI-FINAL-001–004 | It is a custom rebuild of original ESCI Small US Test, not an official ESCI leaderboard result or newly authored human labels. |
| A calibrated, missing-image-aware multimodal retrieval implementation and a controlled ranking study. | ESCI-W4-001–004; ESCI-CAL-001–002; ESCI-W5-001–003; ESCI-TARGET-W4-001 | Implementations and empirical findings using established methods, not new foundational algorithms. |
| Evidence that final ranking gains are modest and the original Week2/5/6 NDCG targets remain unmet; adaptation and additional losses/features did not justify replacing the system. | ESCI-TARGET-WEEK2/5/6; ESCI-FINAL-COMP-*; OPT-P1-*; OPT-P2A-*; OPT-P2B; OPT-TARGET-*; OPT-W6-* | Negative results are completed evidence. Do not portray alternative models as successful components of the final pipeline. |
| A behavior-preserving inference optimization and working natural-language search demo, with finite 64-request queue tests. | ENG-01–08; ENG-10–17; ENG-20 | Same-runtime core equivalence; compatibility-approved online encoding; CPU/HTTP/workload boundaries remain explicit. |
| A documented transition from weak/silver evaluation to human relevance judgments, including a limited human review and important historical controls. | META-01–30 | This motivates evaluation design, not a causal claim that the new labels alone changed performance. |

## 2. Proposed section structure and source mapping

### Abstract — write last

- State the product-search problem and the final modular framework.
- Identify human-judged ESCI+SQID as the main quality benchmark; mention the earlier weak/silver pipeline only if needed to motivate the transition.
- Select a small number of supported results: final ranking gain/target outcome, Warm Known-Positive Recall improvement, same-session core optimization, and the finite online workload.
- State the cold-start/adaptation finding without suggesting a successful learned cold adapter.
- Do not combine different protocols into one headline result or call the system production-ready.

**Supporting IDs:** ESCI-FINAL-*, ESCI-TARGET-*, ENG-05/08/15. The abstract must not introduce a claim absent from the matrix.

### 1. Introduction

1. Product search requires lexical constraints, semantic matching, visual information and ranking.
2. Public product metadata permits engineering experiments but does not itself provide realistic search queries or complete relevance ground truth.
3. Motivate the shift from synthetic queries/silver labels to human ESCI judgments, while acknowledging that those judgments are still sparse over the full catalog.
4. State the implemented scope and the five contribution/finding categories above.

**Supporting files/IDs:** Original outline, page1; META-01/08/26/27; ESCI-DATA-001–005; ESCI-METRIC-002; ENG-01.

### 2. Related Work

- Sparse retrieval and BM25; dense sentence retrieval and SBERT.
- CLIP and multimodal product-search representations; ESCI and SQID as existing datasets.
- Pointwise tree models, LambdaMART and top-one ListNet.
- Contrastive adaptation and supervised-product holdout as a limited cold-generalization proxy.
- RRF as an established rank-combination method; efficient serving as systems engineering.

Use the primary-source registry in `REFERENCE_CHECKLIST.md`. Relate each established method to the code used here. LLM rewriting can receive a short contextual paragraph; it is not a contribution of the final ESCI system. Do not write a survey of unrelated models or describe BGE/Qwen historical components as current dependencies.

### 3. Methodology

#### 3.1 Problem formulation and final architecture

- Define query, product content, image availability, judged candidate pool and full catalog.
- Give one final-system diagram: original query → frozen SBERT/CLIP encoders → calibrated mask-aware Fusion FlatIP Top100 → original28 features → frozen Scaler/ListNet → ranked products.
- Clearly distinguish the offline frozen benchmark vectors from the later compatibility-approved live encoding path.

**IDs:** ESCI-W4-001; ESCI-CAL-001; ESCI-W5-002; OPT-FORMAL-DECISION; ENG-01/07–09.

#### 3.2 Representations, retrieval and calibration

- SBERT384d checkpoint, SQID CLIP768d text/image/query inputs, L2 normalization and ID alignment.
- Original late fusion and the diagnosed missing-image score-scale problem.
- Exact Train-only calibration and mask-aware fallback formulas from the implementation; explain the additional coordinate in the1,153d fused index.
- Exact FlatIP, Top100 and deterministic tie handling.
- Present RRF60 separately as a prespecified evaluated alternative, with equal per-route and merged Top100 budgets.

**IDs/files:** ESCI-DATA-004/005; ESCI-W4-001–004; ESCI-CAL-001/002; OPT-P2C-*; `src/week4_calibration.py`, `src/week4_vectors.py`, `week7_p2/retriever.py`.

#### 3.3 Feature construction and learning to rank

- Group the28 features into lexical, semantic, image and available metadata features. Put every name, mathematical definition, order, dtype and missing-value branch in Appendix B.
- Describe original Week2 XGBoost20 features separately from the Week5 controlled same28-feature XGBoost/LambdaMART/ListNet comparison.
- Give pointwise regression, LambdaMART's relevance-gain configuration and original ListNet grade-softmax objective/MLP architecture.
- Clarify that the system is modular and encoders are frozen; it is not jointly trained end to end.

**IDs:** ESCI-W2-001; ESCI-W5-001/002; ESCI-DATA-003/008; frozen dependency map; ENG-01/06.

#### 3.4 Evaluated cold adaptation and controlled extensions

- Describe two projection-only heads, shared text/query head, L2 output and symmetric InfoNCE as an evaluated alternative, explicitly not part of the final system.
- Summarize P1 weighting/regularization, constraint fields, gain-aware ListNet, the position-aware loss, field matching and pseudo-Cold product exclusion.
- Distinguish trainable objects from frozen objects; keep detailed settings and all folds/checkpoints in the appendix.

**IDs:** ESCI-W6-001–004; OPT-P1-*; OPT-P2A-*; OPT-P2B; OPT-TARGET-A/B/C/D.

#### 3.5 Inference and service design

- Prepared static product data, candidate-key arrays, original feature/scoring equivalence.
- FastAPI/SearchService and HTTP-only Streamlit interface; model/index loading once; real product display.
- Bounded queue and finite product-token cache, one compute slot, clear overload responses.
- Keep low-level process management, dependency isolation and routes in the reproducibility appendix.

**IDs:** ENG-01/02/04/07/12–14/20. Docker is an incomplete delivery item, not a validated component.

### 4. Experimental Setup

#### 4.1 Dataset construction and coverage

- Source revisions, custom original-ESCI-Test selection and SQID joins.
-164,900 products,8,956 queries,181,701 judged pairs;156,100 usable image vectors and8,800 missing/invalid.
- Available fields and absent price/rating/review-history/category variables.

**IDs:** ESCI-DATA-001–005.

#### 4.2 Frozen roles and isolation

- Query70/15/15 and product80/10/10 splits, seed, grouped near-duplicate handling.
- Original pointwise view6,269 queries/101,984 Warm pairs versus LTR view6,171/100,856.
- Warm-Train supervision, separate alignment Warm-Val, Cold-Val selection history, protected Cold-Test and prediction-before-label Final Test lock.
- Product-ID disjointness versus content overlap, explicit Train-Seen diagnostics and deduplicated subsets.
- Internal80/20 and3-fold grouped CV plus pseudo-Cold product holdout for optimization; distinguish these from external development and final evaluation.

**IDs:** ESCI-DATA-006–010; ESCI-FINAL-001–004; ESCI-FINAL-TRAINSEEN-001; OPT-*.

#### 4.3 Metrics and uncertainty

- NDCG@10 with3/2/1/0 grades and7/3/1/0 gains; MAP@10 and untruncated MRR.
- Retain complete candidate competition positions and mask relevance outside the target scope. Do not substitute the misleadingly labeled warm-only diagnostic that drops competitors.
- Catalog Known-Positive Recall@10/50/100,Hit@50 and judgement coverage; unjudged products stay unknown.
- Give eligibility and E/S counts for each scope. Warm/Cold/Overall share queries but have different target masks and IDCG, so Overall is not a weighted average of subgroup NDCGs.
- Query-paired bootstrap settings and limits; do not mix fold means, query macros, training-seed variation or multiplicity-adjusted claims.

**IDs:** ESCI-METRIC-001–003; ESCI-FINAL-003; ESCI-W2-INCONSISTENCY-001; optimization protocol references.

#### 4.4 Models, compute and reproducibility

- List model/config/scaler/index hashes and saved dependency records rather than reprint long SHA strings in the main text.
- Training settings and selection checkpoints, archived source/runtime snapshots and remote-file verification scope.
- Separate Final Test cached CPU timing, A100/T4 engineering sessions, Mac online HTTP and UI functionality.
- No newly run benchmark or model selection in report preparation.

**IDs:** frozen_dependency_map.json; ESCI-FINAL-VERIFICATION-001; ENG-03/05/10/11/15/17.

### 5. Experimental Results and Analysis

#### 5.1 Final judged-pool ranking

- Lead with the four frozen models on Warm, Cold-Test and Overall; include NDCG/MAP/MRR, effective query counts and paired intervals.
- Report Week2+1.20%, LambdaMART+5.80%, ListNet+6.28% on Warm and final ListNet Cold+1.69% against original Week2.
- Explicitly state that the original+5/+12/+15 thresholds were not met; ListNet cannot substitute for the named LambdaMART requirement.
- ListNet's Warm point estimate exceeds LambdaMART, but the paired CI crosses0. Do not label this stable superiority.

**IDs:** ESCI-FINAL-POOL-*; ESCI-TARGET-WEEK2/5/6; ESCI-FINAL-COMP-*.

#### 5.2 Catalog retrieval and reranking

- Sparse/dense/CLIP and original-fusion development trajectory, then Train-calibrated fusion.
- Main final comparison: raw Fusion versus raw SBERT Warm KP-R@50+14.35%, explicitly a known-positive proxy.
- Formal Fusion→ListNet A and registered auxiliary RRF→same ListNet B at equal Top100 budget; keep raw Fusion/RRF/D1 distinct from reranked flows.
- Show missing-image and image-available subgroup tradeoffs and selected positive additions/losses. Favorable final auxiliary RRF does not authorize changing the formal system.

**IDs:** ESCI-W2-CATALOG-*; ESCI-W4-*; ESCI-CAL-*; ESCI-FINAL-CATALOG-*; ESCI-FINAL-RRF-*; OPT-P2C-*.

#### 5.3 Feature ablations

- Use completed Warm Validation retraining ablations, with all model families and the paired image comparison.
- Separate Lexical/Semantic/Image/Metadata groups and explain that overlapping fusion features affect ablation interpretation.
- Do not present the+0.010782 ListNet image-group delta as a new final-Test image ablation or a universal causal image benefit.

**IDs:** ESCI-W5-003; Week5 full-model comparison rows.

#### 5.4 Cold generalization and adaptation

- Final frozen-ranking Cold NDCG and uncertainty against Week2; content-unique and Train-Seen/Unseen diagnostics.
- Frozen/adapted alignment and ranking: mean bidirectionalR@10 decreases0.834896→0.828072; Cold-Val NDCG's small rise is uncertain, Warm decreases and catalogCold KP-R@50 decreases.
- Pseudo-Cold experiment separates product supervision from query groups and retains all competitors. The position-aware loss worsens its primary Cold metric.
- RRF pseudo-Cold/Warm/Cold-Val/Final Test chronology remains visible; no conversion of recall into Cold NDCG.

**IDs:** ESCI-W6-*; ESCI-FINAL-POOL-COLD-*; ESCI-FINAL-TRAINSEEN-001; OPT-W6-*; OPT-TARGET-C/D; OPT-P2C-COLD.

#### 5.5 Controlled optimization outcomes

- Compact main-text summary of all failed directions, not an unbounded hyperparameter narrative.
- Five P1 variants; three constraint-feature models; gain-aware target; position-aware objective; field features; projection heads.
- Prespecified thresholds, fold consistency, confidence intervals, training budget and adoption decisions.
- Put per-fold metrics, curves, exact configurations and numerical replay diagnostics in Appendix D.

**IDs:** all OPT-* and ESCI-W4-PROJECTION-001. These are evaluated negative results, not future work.

#### 5.6 Error cases and historical evaluation comparison

- Qualitatively inspect archived improvements/degradations selected by the existing metric selectors; classify examples only where visible content/ranks support the diagnosis.
- Do not infer prevalence from top-five extreme cases or call speculative mechanisms established causes.
- Give the older metadata pipeline a separate table/panel: fixed100K Week2+19.00%, Week4+24.01% versus raw SBERT, Week5+10.55%, and the separate200-query Week6+14.02%.
- Include strong-text/image-off and CE-only controls beside those historical gains. The earlier48K+21.15% remains report-level evidence pending its complete primary package.
- Report the100-pair full-text human review as a limited agreement study (99 assessable), not human-gold ranking evaluation. Do not interpret cross-benchmark headline differences as architectural causality.

**IDs:** ESCI-ERROR-001; META-01–30. Keep human-review lineage and missing raw historical query-understanding evidence in the appendix.

#### 5.7 Efficiency and serving

- Same-session A0/A1/A2 cached-core comparison and exactness checks.
- Separate genuine online new-query HTTP, later warmed96-query reference, and64-request queue tests.
- Startup/RSS, rejection/recovery, earlier failures and finite-workload limitations.
- Show the English page screenshot as functionality evidence. Do not use it to estimate throughput or claim that every online search is<200ms.

**IDs:** ENG-02–23.

### 6. Discussion

- **Observed:** raw score scales and missing-image handling materially affect catalog retrieval; validation image features can help ranking; alignment adaptation can fail downstream; frozen modular inference can be made substantially faster.
- **Not established:** image information causes all multimodal gain; silver/human score differences isolate label quality; larger LLM parameter count necessarily improves relevance; a frozen-ranker feature-distribution mismatch alone caused projection failure.
- Reconcile targets with the final evidence and explain why the formal model remains frozen despite favorable auxiliary Final Test recall.
- Discuss small subgroup uncertainty, repeated development use, incomplete judgments and the efficiency/queue-wait tradeoff.

**IDs:** ESCI-W4-003; ESCI-W5-003; OPT-W6-*; ESCI-FINAL-RRF-*; META-11/18/24/27; ENG-15/18/23.

### 7. Limitations and Future Work

Separate demonstrated limitations from untested proposals:

- Partial catalog judgments, synthetic historical queries, silver scorer/judge dependence, limited human review and missing independent visual relevance evaluation.
- Product-ID holdout is not actual zero-click history; pretrained encoder exposure and content duplicates are not fully eliminated by ID separation.
- Query-paired intervals exclude training-seed variation and repeated model-selection uncertainty; final Test cannot be recycled for another tuning round.
- Historical SQID identity and cross-CPU exact reproduction remain unresolved; current live operation rests on compatibility evidence.
- Colab external proxy UI acceptance, a current final-system container, dynamic batching, longer-duration/concurrent-browser testing and public production hosting are not completed.
- Actual new-product insertion into the final ESCI service needs implementation/evaluation; the historical subset-index demo is different.
- Future controlled studies could collect independently judged complete query pools, validate visual semantics and test wider deployment workloads. These are conditional proposals, not promised gains or newly authorized experiments.

**IDs:** all Blocked/unresolved, Proposed/not implemented and Implemented/not fully evaluated rows; META-28/30; ENG-09/19/21–23; ESCI-SCOPE-*.

### 8. Conclusion

Summarize only the supported system, empirical quality findings, completed engineering improvements and unresolved targets. Avoid claiming a new ranking algorithm, SOTA result, universal multimodal benefit, a successful Cold adapter, or production readiness.

### References

Use the checked primary sources and verify remaining bibliographic details before constructing `references.bib`. The original project outline is a requirements document, not technical proof. Do not cite a weekly report in place of an available primary result.

### Appendix

- **A:** Dataset lineage, alignment, split logic, eligibility, content duplication and target masking.
- **B:** All28 feature definitions/order/dtypes, calibration equations, fallback and tie handling.
- **C:** Frozen model/index/Scaler identities, dependencies, training and selection configurations.
- **D:** Full P1/P2/targeted/projection outcomes, folds, CIs, curves and failed branches.
- **E:** All final scopes and image/missing/content-unique/Train-Seen metrics, with counts.
- **F:** Historical metadata architecture versions, silver-label provenance, human-review lineage and unresolved48K evidence.
- **G:** Core/online/HTTP measurement protocol, resource traces, UI evidence, numerical portability and deployment limitations.
- **H:** Error examples and reproduction entrypoints; distinguish saved replay verification from new execution.

## 3. Planned tables and figures

| Item | Content | Evidence / boundary |
|---|---|---|
| Table1 | Dataset/protocol lineage and frozen split/image counts | ESCI-DATA-*; META-01/08/20/26. Separate panels, no direct score ranking across benchmarks. |
| Table2 | Final fixed judged-pool ranking,4 models×Warm/Cold/Overall, NDCG/MAP/MRR and n | ESCI-FINAL-POOL-*; paired-comparison rows. |
| Table3 | Full-catalog raw retrieval and formal/auxiliary reranking KP-R/Hit/Coverage | ESCI-FINAL-CATALOG-*; no catalog NDCG. |
| Table4 | Original target outcomes using correct final-test baselines | ESCI-TARGET-*. Index size and latency separate from recall proxy. |
| Table5 | Development feature ablations and image paired result | ESCI-W5-003; Validation only. |
| Table6 | Frozen/adapted alignment, Warm/Cold/Overall and pseudo-Cold diagnostics | ESCI-W6-*; OPT-W6-*; OPT-TARGET-C. |
| Table7 | Controlled optimization summary with gates/adoption | OPT-*; full fold tables appendix. |
| Table8 | Historical fixed100K/200-query outcomes plus matched controls | META-*; do not silently import21.15% from another run. |
| Table9 | Same-environment cached core A0/A1/A2 and equivalence | ENG-03/05/06; no across-machine speedup. |
| Table10 | Online, HTTP and finite64-request load, costs and failures | ENG-10–18. |
| Figure1 | Final architecture with optional research branches clearly detached | ESCI-CAL/W5; ENG-01. |
| Figure2 | Query/product role splits and evaluation target-mask diagram | ESCI-DATA/METRIC/FINAL. |
| Figure3 | Calibration/fallback diagnosis and/or Validation ablation plot | Existing data only; no new labels. |
| Figure4 | Alignment/ranking failure or controlled negative-result plot | Existing curves and CIs, correct development scopes. |
| Figure5 | Core component latency and optional64-load CDF | Reuse verified TikZ figures; identify timing boundaries. |
| Figure6 | English live-search screenshot | Functional illustration; not an independent benchmark sample. |

## 4. Drafting gate and future file plan

The audit and outline are complete when evidence links/statuses, numeric scope, unresolved-claims register and section mapping have passed their recorded checks. The audit does not resolve every missing historical asset, and completion does not authorize new experiments.

**Current stop point:** submit these artifacts for review. Do not begin the full report in this turn.

After approval, create a dedicated LaTeX project with `MMPSR_Final_Report.tex`, `references.bib`, verified figure assets and a compiled PDF. Use a supported academic template without inventing author affiliations, acknowledgements, funding or submission status. Those administrative details can remain omitted or be supplied later.
