# Final appendix technical review

Read-only review of `appendix/technical_details.tex`, its feature/configuration/identity tables, and the complete report's coverage of the original four-page project brief. Compared against preserved implementation code, approved audit claims, and saved aggregate/configuration artifacts. No raw relevance tables were opened; no model, benchmark, or sealed evaluation was executed. Report prose was not edited. Line references identify the initially reviewed appendix and may move during final compilation fixes.

## Factual errors to correct

### A1 — P2: BM25 formula reuses the wrong query-token set

**Location:** `appendix/technical_details.tex:31–36`.

The appendix defines `Q` using the custom **casefold** tokenization, then sums the BM25 formula over `Q \cap V`. Actual BM25 query tokens come from the frozen CountVectorizer's **lowercase** analyzer, not the custom token-set routine. These differ for some Unicode inputs. The paragraph correctly warns that the CountVectorizer is separate, but its equation does not preserve that distinction. Define a separate token set such as `Q_V` for the vectorizer output and use that in the BM25 sum. Source: `project/esci_sqid/src/week2_lexical.py:25–26,52–53,69–76`. This concerns the exact mathematical contract, not a demonstrated benchmark-score difference.

### A2 — P2: Ablation group description misclassifies query length

**Location:** `appendix/technical_details.tex:78`, “The remaining lengths and missing flags are Metadata.”

`query_length` (feature 14) belongs to **Lexical**, because `DEPENDENCIES` assigns the first 14 zero-based columns with `i < 14` to Lexical; title/document length and the missing flags are Metadata. Brand/color lengths are also Metadata. Explicitly exempt `query_length` from the blanket lengths statement. All 28 feature names, their order, and their individual numeric definitions otherwise match the source. Source: `project/esci_sqid/src/week5_features.py:12–16`.

### A3 — P2: Configuration table conflates scaler and feature precision

**Location:** `tables/training_configuration.tex`, row “Frozen Scaler / features”: “Original Train-fit mean/std, float32.”

The frozen scaler **mean and standard deviation are float64**. Standardized feature outputs are cast to float32. The appendix prose correctly describes this path, but the table's compressed wording assigns float32 to mean/std. State the two precisions separately. Source: `project/esci_sqid/src/week5_models.py:61–64,124,130–135`; `week5_features.py:46`.

## Important reproducibility omissions

### A4 — Specify the tested P1 weighting rule and the CV split constants

**Location:** `appendix/technical_details.tex:111–113`.

“Mild extra weight” does not identify the actual tested intervention. Hard weighting selects existing **C/I labels with BM25 at least the query's own Warm 75th percentile and query coverage at least 0.75**, assigns factor **2**, normalizes each query's total weight, then normalizes the global mean to one. Query-balanced weighting uses the same equal-query normalization without the factor-2 rule. Source: `project/esci_sqid/src/p1_refinement.py:86–97`.

For the same recipe to be reconstructible from the appendix, add that P1/P2 split seed is **20261015**, P2 inner stopping holds out **20% of the available query groups** inside each outer fold, and pseudo-Cold product hashing uses seed **20261016**. The currently stated outer fractions and cohort counts are correct. Sources: `p1_refinement.py:20,29–35`; `p2_protocol.py:10,14–22`; `targeted_protocol.py:8–14`.

### A5 — Give the numeric safety margin instead of a qualitative regression rule

**Location:** `appendix/technical_details.tex:129`, “no unexplained quality regression.”

The tested gate is numeric: P2 rejects a **single-fold NDCG delta below -0.002**, while the targeted pseudo-Cold study also requires Warm/Overall paired-interval lower bounds at least **-0.002** and the fold safeguard. The existing average absolute gain threshold **0.002** and positive primary interval lower bound are correct. State the registered margins so the criterion does not appear to be zero-regression or a subjective post hoc explanation. Sources: `project/esci_sqid/src/p2_protocol.py:41–47`; `targeted_workflow.py:44,113–121`.

## Checks completed without another discrepancy

- The complete 28-feature table matches `week2_lexical.py` and `week5_features.py`: unique-token versus occurrence lengths, brand-in-query phrase direction, digit-token coverage, masked image zero, availability indicator, and the misleadingly named raw text-fusion column are all documented correctly.
- Calibration sample counts and all seven stored parameters match the accepted calibration report. Both image-available and missing-image affine coefficients algebraically match `calibrated_clip_scores` and `calibrated_vectors`; the extra-coordinate index representation is correct.
- Scoped AP/MRR/coverage expressions, E/S eligibility despite nonzero C gain, Overall = Warm union Cold-Test, subgroup overlap, and retention of competing positions match the final evaluator.
- The six displayed frozen dependency hash prefixes and registration-stage statuses match `evidence/frozen_dependency_map.json`. The table's two `expected_identity_only_missing_local` rows are correctly qualified as historical registration snapshots, with later execution verification described separately.
- P0 lexical-artifact differences, original Week2 versus Week5 stopping rules, the selected 77/60/180-tree and epoch-6 checkpoints, and original four-thread/model-seed boundaries are consistent with the approved evidence.
- P2 same-fold matched baselines, 20-to-25 versus 28-to-33 feature comparisons, fixed-budget refit, gain-aware target, active-query position-loss averaging, and pseudo-Cold exclusion counts match source/protocol records.
- Engineering core/live/HTTP boundaries, same-runtime exactness versus live compatibility, finite cache/workload limitations, one compute slot, queue bounds, overload behavior, and incomplete Colab/container/public-hosting acceptance are preserved. No unsupported production or cross-CPU bitwise-reproduction claim was found.

## Coverage of the original project brief

The original brief asks for data preparation/EDA, sparse and pointwise baselines, LLM query understanding, multimodal retrieval, LambdaMART/ListNet and ablations, cold generalization/adaptation, API/UI integration and efficiency, error analysis, and academic final reporting. The report accounts for these research/engineering areas and reports the verified completed methods, failed directions, and target outcomes. I found no omitted completed experiment that would materially change its central conclusions.

The report also correctly distinguishes an academically complete **report** from completion of every original project ambition: LLM query-understanding acceptance and manual F1, true zero-click cold labels, independently judged visual relevance, insertion into the final complete index, a validated current container, and production hosting are not manufactured as successes. The brief's presentation deck/demo-video deliverables are separate artifacts; this report does not claim to deliver them. A brief explicit status sentence about those artifacts would be optional, not a missing experimental method or grounds to delay this report.

Original brief reviewed: `/Users/zhangjunhao/Desktop/MMPSR/AI Algorithm Intern Project Outline Multi-Modal Product Search Ranking with LLM-Enhanced Query Understanding.pdf`, pages 1–4. The approved final-report outline remains the governing scope for this artifact.

Outcome: address A1–A3 and add the concise protocol constants in A4–A5; no blocking calibration, metric implementation, identity, or serving-boundary discrepancy was found.
